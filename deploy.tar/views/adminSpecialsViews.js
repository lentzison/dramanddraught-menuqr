const { adminLayout } = require('./adminLayout');
const { imageUploadWidget, imageUploadWidgetCss, imageUploadWidgetScript } = require('./imageUploadWidget');
const { escHTML } = require('./escapeHtml');

const DAYS = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
const DAY_LABELS = { MONDAY: 'Monday', TUESDAY: 'Tuesday', WEDNESDAY: 'Wednesday', THURSDAY: 'Thursday', FRIDAY: 'Friday', SATURDAY: 'Saturday', SUNDAY: 'Sunday' };
const MONTHS = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function buildCategoryOptions(selected, options = []) {
  const merged = ['cocktail', 'beer', 'wine', 'whiskey', 'food', 'other']
    .concat((options || []).map((value) => String(value || '').trim().toLowerCase()))
    .filter(Boolean);

  const seen = new Set();
  const unique = [];
  for (const value of merged) {
    if (seen.has(value)) continue;
    seen.add(value);
    unique.push(value);
  }

  return ['']
    .concat(unique)
    .map((value) => {
      const selectedAttr = value === selected ? ' selected' : '';
      const label = value ? `${value.charAt(0).toUpperCase()}${value.slice(1)}` : 'None';
      return `<option value="${value}"${selectedAttr}>${label}</option>`;
    })
    .join('');
}

// ─── Half-Price Spirit Picker ───
function renderHalfPricePicker(day, theme, actionUrl, spiritCatalog, spiritCategories) {
  const config = theme.halfPriceConfig || {};
  const categories = (spiritCategories && spiritCategories.categories) || [];
  const catalog = spiritCatalog || [];

  const savedCategories = config.categories || [];
  const savedPicks = config.picks || [];
  const savedPickSet = new Set(savedPicks.map(String));
  const priceMin = config.priceMin != null ? config.priceMin : '';
  const priceMax = config.priceMax != null ? config.priceMax : '';

  const WHISKEY_DEFAULTS = ['Bourbon', 'Rye Whiskey', 'Tennessee Whiskey', 'American Whiskey', 'Canadian Whisky', 'Irish Whiskey', 'Blended Scotch', 'Single Malt Scotch', 'Japanese Whisky', 'Whiskey', 'Flavored Whiskey', 'International Whiskey'];
  const AGAVE_DEFAULTS = ['Tequila', 'Mezcal'];

  // Day-based suggestion for first-time setup only; not enforced
  const isWednesday = day === 'WEDNESDAY';
  const isThursday = day === 'THURSDAY';
  const suggestedLabel = isWednesday ? 'Whiskey' : (isThursday ? 'Agave Spirits' : 'Spirits');
  const suggestedCats = isWednesday ? WHISKEY_DEFAULTS : (isThursday ? AGAVE_DEFAULTS : []);

  // Determine active categories: saved config, or day suggestions on first load
  const hasExistingConfig = Object.keys(config).length > 0;
  const activeCategories = hasExistingConfig ? savedCategories : suggestedCats;

  // Label and discount: config-driven with sensible defaults
  const savedLabel = typeof config.label === 'string' && config.label ? config.label : suggestedLabel;
  const savedDiscount = typeof config.discount === 'number' && config.discount > 0 ? config.discount : 50;

  // Group catalog by category for pill counts and table rendering
  const grouped = {};
  catalog.forEach(s => {
    const cat = s.primaryCategory || 'Uncategorized';
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(s);
  });
  const sortedCats = Object.keys(grouped).sort();

  // Build category pill HTML (pills are for categories present in the catalog, with count badges)
  const catalogCatSet = new Set(sortedCats);
  const pillList = categories.filter(c => catalogCatSet.has(c));
  // Add any catalog categories that weren't in the master list (fallback)
  sortedCats.forEach(c => { if (!pillList.includes(c)) pillList.push(c); });
  const categoryPills = pillList.map(cat => {
    const active = activeCategories.includes(cat);
    const count = grouped[cat] ? grouped[cat].length : 0;
    return `<button type="button" class="hp-pill${active ? ' hp-pill-active' : ''}" data-hp-cat="${escHTML(cat)}">
      <span class="hp-pill-label">${escHTML(cat)}</span>
      <span class="hp-pill-count">${count}</span>
    </button>`;
  }).join('');

  // Build table rows grouped by category
  let tableRows = '';
  for (const cat of sortedCats) {
    const spirits = grouped[cat];
    const selectedInGroup = spirits.filter(s => savedPickSet.has(String(s.productId))).length;
    tableRows += `<tr class="hp-group-header" data-hp-group="${escHTML(cat)}">
      <td colspan="4">
        <div class="hp-group-header-inner">
          <div class="hp-group-title">
            <span class="hp-group-label">${escHTML(cat)}</span>
            <span class="hp-group-count">${spirits.length}</span>
            <span class="hp-group-selected" data-hp-gsel="${escHTML(cat)}">${selectedInGroup > 0 ? `${selectedInGroup} selected` : ''}</span>
          </div>
          <div class="hp-group-actions">
            <button type="button" class="hp-grp-btn hp-grp-selall" data-hp-grpact="${escHTML(cat)}">Select all</button>
            <button type="button" class="hp-grp-btn hp-grp-selnone" data-hp-grpclr="${escHTML(cat)}">Clear</button>
          </div>
        </div>
      </td>
    </tr>`;
    for (const s of spirits) {
      const checked = savedPickSet.has(String(s.productId)) ? ' checked' : '';
      const halfPrice = s.oneOzPrice ? (s.oneOzPrice / 2).toFixed(0) : '';
      tableRows += `<tr class="hp-row${checked ? ' hp-row-picked' : ''}" data-hp-id="${escHTML(s.productId)}" data-hp-cat="${escHTML(s.primaryCategory || '')}" data-hp-name="${escHTML(s.name.toLowerCase())}" data-hp-price="${s.oneOzPrice || ''}" tabindex="0">
        <td class="hp-cell-cb"><input type="checkbox" class="hp-spirit-cb" value="${escHTML(s.productId)}"${checked} aria-label="Select ${escHTML(s.name)}" /></td>
        <td class="hp-cell-name">${escHTML(s.name)}</td>
        <td class="hp-cell-price">${s.oneOzPrice ? `$${s.oneOzPrice}` : '<span class="hp-na">—</span>'}</td>
        <td class="hp-cell-half">${s.oneOzPrice ? `$${halfPrice}` : ''}</td>
      </tr>`;
    }
  }

  const catalogJSON = JSON.stringify(catalog.map(s => ({
    id: s.productId,
    name: s.name,
    cat: s.primaryCategory,
    price: s.oneOzPrice,
  })));

  const emptyCatalog = catalog.length === 0;

  return `
    <div class="card hp-picker" id="hp-picker">
      <style>
        /* No overflow:hidden so position:sticky on .hp-summary works against the viewport */
        .hp-picker { background: #1a1a1a; border: 1px solid #2a2a2a; padding: 0; border-radius: 12px; }
        .hp-picker .hp-head {
          padding: 20px 24px;
          background: linear-gradient(135deg, rgba(212,175,55,0.08), rgba(184,115,51,0.04));
          border-bottom: 1px solid #2a2a2a;
          border-radius: 12px 12px 0 0;
        }
        .hp-picker .hp-head h2 { margin: 0 0 4px; font-size: 1.25rem; color: #d4af37; }
        .hp-picker .hp-head p { color: #888; font-size: 0.88rem; margin: 0; }

        .hp-picker .hp-section { padding: 20px 24px; border-bottom: 1px solid #222; }
        .hp-picker .hp-section:last-of-type { border-bottom: none; }
        .hp-picker .hp-section-label {
          display: block;
          font-size: 0.72rem;
          font-weight: 700;
          color: #888;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          margin-bottom: 14px;
        }

        /* Sticky summary bar */
        .hp-picker .hp-summary {
          position: sticky; top: 10px; z-index: 5;
          margin: 16px 24px 0;
          padding: 14px 18px;
          background: linear-gradient(135deg, #1e1e1e, #1a1a1a);
          border: 1px solid #3a3a3a;
          border-radius: 12px;
          display: flex;
          align-items: center;
          gap: 16px;
          flex-wrap: wrap;
          box-shadow: 0 8px 24px rgba(0,0,0,0.4);
        }
        .hp-picker .hp-summary-stat { display: flex; align-items: baseline; gap: 6px; }
        .hp-picker .hp-summary-num {
          font-size: 1.5rem; font-weight: 800;
          background: linear-gradient(135deg, #d4af37, #b87333);
          -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }
        .hp-picker .hp-summary-lbl { color: #888; font-size: 0.85rem; }
        .hp-picker .hp-summary-sep { width: 1px; height: 24px; background: #333; }
        .hp-picker .hp-summary-discount {
          background: rgba(212,175,55,0.15);
          color: #d4af37;
          padding: 6px 12px;
          border-radius: 20px;
          font-weight: 700;
          font-size: 0.85rem;
        }
        .hp-picker .hp-dirty-badge {
          display: none;
          align-items: center;
          gap: 6px;
          background: rgba(224,138,60,0.15);
          color: #e08a3c;
          padding: 5px 10px;
          border-radius: 20px;
          font-size: 0.78rem;
          font-weight: 600;
        }
        .hp-picker .hp-dirty-badge.is-dirty { display: inline-flex; }
        .hp-picker .hp-dirty-dot { width: 6px; height: 6px; background: #e08a3c; border-radius: 50%; animation: hp-pulse 1.6s ease-in-out infinite; }
        @keyframes hp-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .hp-picker .hp-summary-actions { margin-left: auto; display: flex; gap: 8px; align-items: center; }

        /* Display + preview */
        .hp-picker .hp-display-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: start; }
        .hp-picker .hp-display-fields label { margin-top: 0; }
        .hp-picker .hp-display-fields .form-row { margin-top: 12px; }
        .hp-picker .hp-preview {
          background: #0d0d0d;
          border: 1px solid #2a2a2a;
          border-radius: 10px;
          padding: 16px 18px;
        }
        .hp-picker .hp-preview-hint {
          font-size: 0.68rem;
          font-weight: 700;
          color: #666;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          margin-bottom: 10px;
        }
        .hp-picker .hp-preview-title {
          font-size: 1.05rem;
          font-weight: 700;
          color: #d4af37;
          margin-bottom: 4px;
        }
        .hp-picker .hp-preview-sub { color: #888; font-size: 0.82rem; margin-bottom: 12px; }
        .hp-picker .hp-preview-ex {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 8px 10px;
          background: #151515;
          border-radius: 6px;
          font-size: 0.85rem;
        }
        .hp-picker .hp-preview-ex-name { color: #ccc; font-weight: 500; }
        .hp-picker .hp-preview-ex-prices { display: flex; gap: 8px; align-items: baseline; }
        .hp-picker .hp-preview-ex-prices s { color: #666; font-size: 0.78rem; }
        .hp-picker .hp-preview-ex-prices strong { color: #d4af37; font-size: 0.95rem; }
        .hp-picker .hp-preview-empty { color: #555; font-size: 0.82rem; font-style: italic; }

        /* Pills */
        .hp-picker .hp-pills {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .hp-picker .hp-pill {
          background: #111;
          border: 1px solid #2a2a2a;
          color: #aaa;
          padding: 6px 10px 6px 12px;
          border-radius: 20px;
          font-size: 0.82rem;
          cursor: pointer;
          transition: all 0.15s;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-family: inherit;
        }
        .hp-picker .hp-pill:hover { border-color: rgba(212,175,55,0.5); color: #d4af37; }
        .hp-picker .hp-pill-count {
          background: #222;
          color: #888;
          padding: 1px 7px;
          border-radius: 10px;
          font-size: 0.72rem;
          font-weight: 600;
        }
        .hp-picker .hp-pill-active { background: rgba(212,175,55,0.15); border-color: #d4af37; color: #d4af37; font-weight: 600; }
        .hp-picker .hp-pill-active .hp-pill-count { background: rgba(212,175,55,0.25); color: #d4af37; }

        /* Filter row */
        .hp-picker .hp-filter-grid {
          display: grid;
          grid-template-columns: 2fr 1fr 1fr;
          gap: 12px;
          margin-bottom: 14px;
        }
        .hp-picker .hp-filter-grid label { margin-top: 0; }
        .hp-picker .hp-search-input {
          background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23666' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><circle cx='11' cy='11' r='8'/><line x1='21' y1='21' x2='16.65' y2='16.65'/></svg>");
          background-repeat: no-repeat;
          background-position: 12px center;
          padding-left: 36px !important;
        }

        /* Action toolbar */
        .hp-picker .hp-toolbar {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 10px 14px;
          background: #111;
          border: 1px solid #2a2a2a;
          border-radius: 8px 8px 0 0;
          border-bottom: none;
          flex-wrap: wrap;
        }
        .hp-picker .hp-toolbar .hp-bulk-btn {
          background: #222;
          border: 1px solid #333;
          color: #ccc;
          padding: 5px 11px;
          border-radius: 6px;
          font-size: 0.78rem;
          cursor: pointer;
          font-family: inherit;
          transition: all 0.15s;
        }
        .hp-picker .hp-toolbar .hp-bulk-btn:hover { border-color: #d4af37; color: #d4af37; }
        .hp-picker .hp-view-btns {
          display: inline-flex;
          background: #0d0d0d;
          border: 1px solid #333;
          border-radius: 6px;
          overflow: hidden;
        }
        .hp-picker .hp-view-btn {
          background: transparent;
          border: none;
          color: #888;
          padding: 5px 12px;
          font-size: 0.78rem;
          cursor: pointer;
          font-family: inherit;
          transition: all 0.15s;
        }
        .hp-picker .hp-view-btn:not(:last-child) { border-right: 1px solid #2a2a2a; }
        .hp-picker .hp-view-btn:hover { color: #d4af37; }
        .hp-picker .hp-view-btn.hp-vb-active { background: rgba(212,175,55,0.15); color: #d4af37; font-weight: 600; }
        .hp-picker .hp-counts {
          margin-left: auto;
          color: #888;
          font-size: 0.82rem;
          white-space: nowrap;
        }
        .hp-picker .hp-counts strong { color: #d4af37; font-weight: 700; }

        /* Table */
        .hp-picker .hp-table-wrap {
          max-height: 60vh;
          overflow-y: auto;
          border: 1px solid #2a2a2a;
          border-top: none;
          border-radius: 0 0 8px 8px;
          background: #0d0d0d;
        }
        .hp-picker .hp-table { width: 100%; border-collapse: collapse; }
        .hp-picker .hp-group-header td {
          padding: 0;
          background: #151515;
          border-bottom: 1px solid #2a2a2a;
          position: sticky;
          top: 0;
          z-index: 1;
        }
        .hp-picker .hp-group-header-inner {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 14px;
          gap: 10px;
        }
        .hp-picker .hp-group-title { display: flex; align-items: center; gap: 8px; }
        .hp-picker .hp-group-label { font-weight: 700; color: #d4af37; font-size: 0.82rem; text-transform: uppercase; letter-spacing: 0.05em; }
        .hp-picker .hp-group-count { color: #666; font-size: 0.78rem; background: #222; padding: 2px 8px; border-radius: 10px; font-weight: 600; }
        .hp-picker .hp-group-selected { color: #8cb369; font-size: 0.76rem; font-weight: 600; }
        .hp-picker .hp-group-actions { display: flex; gap: 4px; }
        .hp-picker .hp-grp-btn {
          background: transparent;
          border: 1px solid #333;
          color: #888;
          padding: 3px 9px;
          border-radius: 4px;
          font-size: 0.72rem;
          cursor: pointer;
          font-family: inherit;
          transition: all 0.15s;
        }
        .hp-picker .hp-grp-btn:hover { border-color: #d4af37; color: #d4af37; }

        .hp-picker .hp-row {
          cursor: pointer;
          transition: background 0.1s;
        }
        .hp-picker .hp-row:focus { outline: 2px solid rgba(212,175,55,0.5); outline-offset: -2px; }
        .hp-picker .hp-row td {
          padding: 9px 14px;
          border-bottom: 1px solid #1a1a1a;
          font-size: 0.88rem;
          color: #ccc;
        }
        .hp-picker .hp-row:hover td { background: #151515; }
        .hp-picker .hp-row-picked {
          background: linear-gradient(90deg, rgba(140,179,105,0.08), transparent 60%);
          box-shadow: inset 3px 0 0 #8cb369;
        }
        .hp-picker .hp-row-picked .hp-cell-name { color: #c5e1a5; }
        .hp-picker .hp-cell-cb { width: 36px; text-align: center; }
        .hp-picker .hp-cell-cb input[type="checkbox"] {
          width: 16px; height: 16px;
          accent-color: #d4af37;
          cursor: pointer;
        }
        .hp-picker .hp-cell-name { font-weight: 500; }
        .hp-picker .hp-cell-price { color: #888; font-size: 0.85rem; text-align: right; white-space: nowrap; }
        .hp-picker .hp-cell-half { color: #d4af37; font-weight: 700; font-size: 0.9rem; text-align: right; white-space: nowrap; }
        .hp-picker .hp-na { color: #444; }
        .hp-picker .hp-row-hidden { display: none; }

        .hp-picker .hp-empty {
          text-align: center;
          padding: 40px 20px;
          color: #666;
        }
        .hp-picker .hp-empty-icon { font-size: 2rem; opacity: 0.4; margin-bottom: 8px; }
        .hp-picker .hp-empty-title { color: #888; font-weight: 600; margin-bottom: 4px; }
        .hp-picker .hp-empty-sub { font-size: 0.85rem; }

        @media (max-width: 768px) {
          .hp-picker .hp-display-row { grid-template-columns: 1fr; }
          .hp-picker .hp-filter-grid { grid-template-columns: 1fr; }
          .hp-picker .hp-summary { margin: 12px 16px 0; padding: 12px; }
          .hp-picker .hp-summary-actions { margin-left: 0; width: 100%; }
          .hp-picker .hp-head,
          .hp-picker .hp-section { padding: 16px; }
          .hp-picker .hp-group-header-inner { flex-direction: column; align-items: flex-start; gap: 6px; }
          .hp-picker .hp-counts { margin-left: 0; width: 100%; }
        }
      </style>

      <div class="hp-head">
        <h2>Discounted Spirits</h2>
        <p>Pick which spirits guests see on this day's specials page at a discount.</p>
      </div>

      <!-- Sticky summary bar -->
      <div class="hp-summary">
        <div class="hp-summary-stat">
          <span class="hp-summary-num" id="hp-summary-count">0</span>
          <span class="hp-summary-lbl">of ${catalog.length} selected</span>
        </div>
        <div class="hp-summary-sep"></div>
        <div class="hp-summary-discount" id="hp-summary-discount">${savedDiscount}% off</div>
        <span class="hp-dirty-badge" id="hp-dirty-badge">
          <span class="hp-dirty-dot"></span> Unsaved changes
        </span>
        <div class="hp-summary-actions">
          <form method="POST" action="${actionUrl}" id="hp-save-form" style="margin:0">
            <input type="hidden" name="_action" value="saveHalfPrice" />
            <input type="hidden" name="halfPriceConfig" id="hp-config-json" value="${escHTML(JSON.stringify(config))}" />
            <button type="submit" class="btn btn-primary">Save Selection</button>
          </form>
        </div>
      </div>

      <!-- Section: How guests see it -->
      <div class="hp-section">
        <span class="hp-section-label">How guests see it</span>
        <div class="hp-display-row">
          <div class="hp-display-fields">
            <label for="hp-label">Section Title</label>
            <input type="text" id="hp-label" value="${escHTML(savedLabel)}" placeholder="e.g. Whiskey, Agave Spirits" />
            <div class="form-row">
              <div>
                <label for="hp-discount">Discount %</label>
                <input type="number" id="hp-discount" value="${escHTML(String(savedDiscount))}" min="1" max="99" step="1" />
              </div>
              <div>
                <label>&nbsp;</label>
                <div style="color:#666; font-size:0.8rem; padding-top:12px">Applies to all selected spirits</div>
              </div>
            </div>
          </div>
          <div class="hp-preview">
            <div class="hp-preview-hint">Live Preview</div>
            <div class="hp-preview-title" id="hp-preview-title">Half-Price Whiskey</div>
            <div class="hp-preview-sub" id="hp-preview-sub">50% off select spirits &mdash; tonight only</div>
            <div class="hp-preview-ex" id="hp-preview-ex">
              <span class="hp-preview-empty">Select spirits below to see a price example</span>
            </div>
          </div>
        </div>
      </div>

      ${emptyCatalog ? `
      <div class="hp-section">
        <div class="hp-empty">
          <div class="hp-empty-icon">◌</div>
          <div class="hp-empty-title">No spirits loaded</div>
          <div class="hp-empty-sub">The bartender database didn't return any spirits for this location.</div>
        </div>
      </div>
      ` : `
      <!-- Section: Filter -->
      <div class="hp-section">
        <span class="hp-section-label">Find spirits</span>
        <div class="hp-filter-grid">
          <div>
            <label for="hp-search">Search</label>
            <input type="text" id="hp-search" class="hp-search-input" placeholder="Search spirits by name..." />
          </div>
          <div>
            <label for="hp-priceMin">Min $/oz</label>
            <input type="number" id="hp-priceMin" value="${escHTML(String(priceMin))}" min="0" step="1" placeholder="0" />
          </div>
          <div>
            <label for="hp-priceMax">Max $/oz</label>
            <input type="number" id="hp-priceMax" value="${escHTML(String(priceMax))}" min="0" step="1" placeholder="any" />
          </div>
        </div>
        <label style="display:block; margin-bottom:8px; color:#888; font-size:0.82rem">Categories <span style="color:#555">&mdash; click to filter the list below</span></label>
        <div class="hp-pills" id="hp-pills">
          ${categoryPills || '<span style="color:#666">No categories loaded</span>'}
        </div>
      </div>

      <!-- Section: Pick -->
      <div class="hp-section">
        <span class="hp-section-label">Select spirits</span>
        <div class="hp-toolbar">
          <button type="button" class="hp-bulk-btn" id="hp-select-all">Select all shown</button>
          <button type="button" class="hp-bulk-btn" id="hp-deselect-all">Clear shown</button>
          <div class="hp-view-btns">
            <button type="button" class="hp-view-btn hp-vb-active" data-hp-view="all">All</button>
            <button type="button" class="hp-view-btn" data-hp-view="selected">Selected</button>
            <button type="button" class="hp-view-btn" data-hp-view="unselected">Unselected</button>
          </div>
          <span class="hp-counts" id="hp-counts">&mdash;</span>
        </div>
        <div class="hp-table-wrap">
          <table class="hp-table" id="hp-table">
            <tbody>${tableRows}</tbody>
          </table>
        </div>
      </div>
      `}
    </div>

    <script>
    (function() {
      var catalog = ${catalogJSON};
      var configInput = document.getElementById('hp-config-json');
      var pills = document.querySelectorAll('#hp-picker .hp-pill');
      var rows = document.querySelectorAll('#hp-picker .hp-row');
      var groupHeaders = document.querySelectorAll('#hp-picker .hp-group-header');
      var priceMinEl = document.getElementById('hp-priceMin');
      var priceMaxEl = document.getElementById('hp-priceMax');
      var searchEl = document.getElementById('hp-search');
      var selectAllBtn = document.getElementById('hp-select-all');
      var deselectAllBtn = document.getElementById('hp-deselect-all');
      var countsEl = document.getElementById('hp-counts');
      var labelEl = document.getElementById('hp-label');
      var discountEl = document.getElementById('hp-discount');
      var dirtyBadge = document.getElementById('hp-dirty-badge');
      var summaryCount = document.getElementById('hp-summary-count');
      var summaryDiscount = document.getElementById('hp-summary-discount');
      var previewTitle = document.getElementById('hp-preview-title');
      var previewSub = document.getElementById('hp-preview-sub');
      var previewEx = document.getElementById('hp-preview-ex');
      var saveForm = document.getElementById('hp-save-form');
      var initialSnapshot = null;
      var viewMode = 'all';
      var saving = false;

      function getDiscount() {
        var d = discountEl && discountEl.value ? parseInt(discountEl.value, 10) : 50;
        if (isNaN(d) || d <= 0 || d >= 100) d = 50;
        return d;
      }
      function getLabel() {
        return labelEl && labelEl.value.trim() ? labelEl.value.trim() : 'Spirits';
      }
      function recomputePriceCells() {
        var disc = getDiscount();
        rows.forEach(function(row) {
          var price = row.getAttribute('data-hp-price');
          var cell = row.querySelector('.hp-cell-half');
          if (!cell) return;
          if (!price) { cell.textContent = ''; return; }
          var p = parseFloat(price);
          if (isNaN(p)) { cell.textContent = ''; return; }
          cell.textContent = '$' + (p * (100 - disc) / 100).toFixed(0);
        });
      }
      function updatePreview() {
        var disc = getDiscount();
        var lbl = getLabel();
        if (previewTitle) previewTitle.textContent = disc === 50 ? ('Half-Price ' + lbl) : (disc + '% Off ' + lbl);
        if (previewSub) previewSub.textContent = disc + '% off select spirits \u2014 tonight only';
        if (summaryDiscount) summaryDiscount.textContent = disc + '% off';

        if (previewEx) {
          // Find first selected spirit with a price, or fall back to first visible with a price
          var exSpirit = null;
          for (var i = 0; i < rows.length; i++) {
            var cb = rows[i].querySelector('.hp-spirit-cb');
            var priceAttr = rows[i].getAttribute('data-hp-price');
            if (cb && cb.checked && priceAttr) {
              exSpirit = {
                name: rows[i].querySelector('.hp-cell-name').textContent,
                price: parseFloat(priceAttr)
              };
              break;
            }
          }
          if (exSpirit) {
            var discounted = (exSpirit.price * (100 - disc) / 100).toFixed(0);
            previewEx.innerHTML =
              '<span class="hp-preview-ex-name">' + exSpirit.name + '</span>' +
              '<span class="hp-preview-ex-prices"><s>$' + exSpirit.price + '</s> <strong>$' + discounted + '</strong></span>';
          } else {
            previewEx.innerHTML = '<span class="hp-preview-empty">Select spirits below to see a price example</span>';
          }
        }
      }
      function markDirty() {
        if (!dirtyBadge || initialSnapshot === null) return;
        if (configInput && configInput.value !== initialSnapshot) {
          dirtyBadge.classList.add('is-dirty');
        } else {
          dirtyBadge.classList.remove('is-dirty');
        }
      }

      // --- View mode (All / Selected / Unselected) ---
      document.querySelectorAll('#hp-picker .hp-view-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
          document.querySelectorAll('#hp-picker .hp-view-btn').forEach(function(b) { b.classList.remove('hp-vb-active'); });
          btn.classList.add('hp-vb-active');
          viewMode = btn.getAttribute('data-hp-view');
          applyFilters();
        });
      });

      // --- Category pills: filter view only ---
      pills.forEach(function(pill) {
        pill.addEventListener('click', function() {
          pill.classList.toggle('hp-pill-active');
          applyFilters();
        });
      });

      // --- Per-group select all / deselect all (only visible rows) ---
      document.querySelectorAll('#hp-picker .hp-grp-selall').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
          e.stopPropagation();
          var cat = btn.getAttribute('data-hp-grpact');
          rows.forEach(function(row) {
            if (row.getAttribute('data-hp-cat') === cat && !row.classList.contains('hp-row-hidden')) {
              var cb = row.querySelector('.hp-spirit-cb');
              if (cb) { cb.checked = true; row.classList.add('hp-row-picked'); }
            }
          });
          updateCounts(); buildConfig(); applyFilters();
        });
      });
      document.querySelectorAll('#hp-picker .hp-grp-selnone').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
          e.stopPropagation();
          var cat = btn.getAttribute('data-hp-grpclr');
          rows.forEach(function(row) {
            if (row.getAttribute('data-hp-cat') === cat && !row.classList.contains('hp-row-hidden')) {
              var cb = row.querySelector('.hp-spirit-cb');
              if (cb) { cb.checked = false; row.classList.remove('hp-row-picked'); }
            }
          });
          updateCounts(); buildConfig(); applyFilters();
        });
      });

      function getActiveCategories() {
        return Array.from(document.querySelectorAll('#hp-picker .hp-pill-active')).map(function(p) { return p.getAttribute('data-hp-cat'); });
      }

      // --- Filtering ---
      function applyFilters() {
        var activeCats = getActiveCategories();
        var minP = priceMinEl && priceMinEl.value ? parseFloat(priceMinEl.value) : null;
        var maxP = priceMaxEl && priceMaxEl.value ? parseFloat(priceMaxEl.value) : null;
        var q = searchEl ? (searchEl.value || '').toLowerCase().trim() : '';

        var visibleByGroup = {};
        var selectedByGroup = {};
        rows.forEach(function(row) {
          var cat = row.getAttribute('data-hp-cat');
          var name = row.getAttribute('data-hp-name');
          var price = row.getAttribute('data-hp-price') ? parseFloat(row.getAttribute('data-hp-price')) : null;
          var cb = row.querySelector('.hp-spirit-cb');
          var isChecked = cb && cb.checked;

          var catOk = activeCats.length === 0 || activeCats.indexOf(cat) !== -1;
          var priceOk = true;
          if (minP !== null && (price === null || price < minP)) priceOk = false;
          if (maxP !== null && (price === null || price > maxP)) priceOk = false;
          var searchOk = !q || name.indexOf(q) !== -1;

          var filterPass = catOk && priceOk && searchOk;
          var viewPass = true;
          if (viewMode === 'selected' && !isChecked) viewPass = false;
          if (viewMode === 'unselected' && isChecked) viewPass = false;

          var visible = filterPass && viewPass;
          if (visible) {
            row.classList.remove('hp-row-hidden');
            visibleByGroup[cat] = (visibleByGroup[cat] || 0) + 1;
          } else {
            row.classList.add('hp-row-hidden');
          }
          if (isChecked) selectedByGroup[cat] = (selectedByGroup[cat] || 0) + 1;
        });

        groupHeaders.forEach(function(hdr) {
          var g = hdr.getAttribute('data-hp-group');
          var cnt = visibleByGroup[g] || 0;
          var sel = selectedByGroup[g] || 0;
          if (cnt > 0) {
            hdr.classList.remove('hp-row-hidden');
            var countSpan = hdr.querySelector('.hp-group-count');
            if (countSpan) countSpan.textContent = cnt;
            var selSpan = hdr.querySelector('.hp-group-selected');
            if (selSpan) selSpan.textContent = sel > 0 ? sel + ' selected' : '';
          } else {
            hdr.classList.add('hp-row-hidden');
          }
        });

        updateCounts();
        buildConfig();
      }

      // --- Counts ---
      function updateCounts() {
        var visibleCount = 0;
        var pickedCount = 0;
        rows.forEach(function(row) {
          if (!row.classList.contains('hp-row-hidden')) visibleCount++;
          var cb = row.querySelector('.hp-spirit-cb');
          if (cb && cb.checked) pickedCount++;
        });
        if (countsEl) countsEl.innerHTML = '<strong>' + visibleCount + '</strong> shown \u00b7 <strong>' + pickedCount + '</strong> picked';
        if (summaryCount) summaryCount.textContent = pickedCount;
      }

      // --- Select all / deselect visible spirits only ---
      if (selectAllBtn) selectAllBtn.addEventListener('click', function() {
        rows.forEach(function(row) {
          if (row.classList.contains('hp-row-hidden')) return;
          var cb = row.querySelector('.hp-spirit-cb');
          if (cb) { cb.checked = true; row.classList.add('hp-row-picked'); }
        });
        updateCounts(); buildConfig(); updatePreview();
      });
      if (deselectAllBtn) deselectAllBtn.addEventListener('click', function() {
        rows.forEach(function(row) {
          if (row.classList.contains('hp-row-hidden')) return;
          var cb = row.querySelector('.hp-spirit-cb');
          if (cb) { cb.checked = false; row.classList.remove('hp-row-picked'); }
        });
        updateCounts(); buildConfig(); updatePreview();
      });

      // --- Build config JSON ---
      function buildConfig() {
        var config = {};
        if (labelEl && labelEl.value.trim()) config.label = labelEl.value.trim();
        config.discount = getDiscount();
        config.categories = getActiveCategories();
        if (priceMinEl && priceMinEl.value) config.priceMin = parseFloat(priceMinEl.value);
        if (priceMaxEl && priceMaxEl.value) config.priceMax = parseFloat(priceMaxEl.value);
        var picks = [];
        rows.forEach(function(row) {
          var cb = row.querySelector('.hp-spirit-cb');
          if (!cb) return;
          if (cb.checked) picks.push(cb.value);
        });
        config.picks = picks;
        if (configInput) configInput.value = JSON.stringify(config);
        markDirty();
      }

      // --- Row click to toggle ---
      rows.forEach(function(row) {
        var cb = row.querySelector('.hp-spirit-cb');
        row.addEventListener('click', function(e) {
          if (e.target === cb) return; // let checkbox handle itself
          if (cb) {
            cb.checked = !cb.checked;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
          }
        });
        row.addEventListener('keydown', function(e) {
          if (e.key === ' ' || e.key === 'Enter') {
            e.preventDefault();
            if (cb) {
              cb.checked = !cb.checked;
              cb.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }
        });
        if (cb) cb.addEventListener('change', function() {
          if (cb.checked) row.classList.add('hp-row-picked');
          else row.classList.remove('hp-row-picked');
          updateCounts(); buildConfig(); updatePreview();
        });
      });

      // --- Event listeners ---
      if (priceMinEl) priceMinEl.addEventListener('input', applyFilters);
      if (priceMaxEl) priceMaxEl.addEventListener('input', applyFilters);
      if (searchEl) searchEl.addEventListener('input', applyFilters);
      if (labelEl) labelEl.addEventListener('input', function() { updatePreview(); buildConfig(); });
      if (discountEl) discountEl.addEventListener('input', function() { recomputePriceCells(); updatePreview(); buildConfig(); });

      // Cmd/Ctrl+S to save
      document.addEventListener('keydown', function(e) {
        if ((e.metaKey || e.ctrlKey) && e.key === 's') {
          var picker = document.getElementById('hp-picker');
          if (picker && saveForm) {
            e.preventDefault();
            saving = true;
            saveForm.submit();
          }
        }
      });

      // Warn on navigation if there are unsaved changes
      window.addEventListener('beforeunload', function(e) {
        if (!saving && dirtyBadge && dirtyBadge.classList.contains('is-dirty')) {
          e.preventDefault();
          e.returnValue = '';
        }
      });
      if (saveForm) saveForm.addEventListener('submit', function() { saving = true; });

      // Init
      recomputePriceCells();
      applyFilters();
      updatePreview();
      if (configInput) initialSnapshot = configInput.value;
    })();
    </script>
  `;
}

// ─── 7-Day Grid Dashboard ───
// Optional opts:
//   - locationSlug: if set, day cards link to that location's override editor and the
//     intro text reflects single-location editing.
//   - locationName: friendly name to show in the heading.
//   - locationOptions: when provided, renders a row of location tabs at the top.
function specialsDashboard(themes, user, flashMsg, opts = {}) {
  const themeMap = {};
  themes.forEach(t => { themeMap[t.dayOfWeek] = t; });

  const locationSlug = opts.locationSlug || '';
  const locationName = opts.locationName || '';
  const locSegment = locationSlug ? `/location/${locationSlug}` : '';

  const grid = DAYS.map(day => {
    const theme = themeMap[day];
    return `
      <a href="/admin/specials/day/${day}${locSegment}" class="admin-card-link">
        <div class="admin-card-title">${DAY_LABELS[day]}</div>
        <div class="admin-card-meta">${theme ? escHTML(theme.name) : 'No theme set yet'}</div>
        <div class="admin-card-footer">
          ${theme ? `<span class="tag ${theme.isActive ? 'tag-active' : 'tag-inactive'}">${theme.isActive ? 'Active' : 'Inactive'}</span>` : '<span class="tag tag-warning">Needs setup</span>'}
          <span>${theme ? `${theme.specials.length} special${theme.specials.length !== 1 ? 's' : ''}` : 'Edit day'}</span>
        </div>
      </a>
    `;
  }).join('');

  const locationTabs = (opts.locationOptions && opts.locationOptions.length > 1) ? `
    <div class="admin-tabs" style="margin-bottom:18px">
      ${opts.locationOptions.map(l => `<a href="/admin/specials?location=${escHTML(l.slug)}" class="btn ${l.slug === locationSlug ? 'btn-primary' : 'btn-secondary'} btn-sm">${escHTML(l.name)}</a>`).join('')}
    </div>` : '';

  const heading = locationSlug && locationName
    ? `Daily Specials &mdash; ${escHTML(locationName)}`
    : 'Daily Specials';
  const intro = locationSlug
    ? `Manage the weekly programming for ${escHTML(locationName || 'your location')}. Click a day to edit its theme and specials.`
    : 'Manage the weekly programming for all locations. Click a day to edit its theme and specials.';

  return adminLayout('Daily Specials', `
    <div class="page-header">
      <div>
        <div class="admin-kicker">Weekly programming</div>
        <h1>${heading}</h1>
        <p class="page-subtitle">${intro}</p>
      </div>
    </div>
    <div class="admin-help"><strong>How this works:</strong> The company default is the baseline. Location tabs override only the selected location when inventory, pricing, or promos differ.</div>
    ${locationTabs}
    <div class="admin-grid">${grid}</div>
  `, user, { pathname: '/admin/specials', flashMsg });
}

// ─── Day Theme Editor ───
function dayThemeEditor(day, theme, specials, locations, locationSlug, user, message, categoryOptions = [], flashMsg, spiritCatalog = [], spiritCategories = {}, halfPriceTheme = null, opts = {}) {
  const isNew = !theme;
  const isOverride = !!locationSlug;
  const loc = locationSlug ? locations.find(l => l.slug === locationSlug) : null;
  const showCompanyDefault = opts.showCompanyDefault !== false;

  const overrideTabs = locations.length > 0 ? `
    <div class="admin-tabs" style="margin-bottom:20px">
      ${showCompanyDefault ? `<a href="/admin/specials/day/${day}" class="btn ${!isOverride ? 'btn-primary' : 'btn-secondary'} btn-sm">Company Default</a>` : ''}
      ${locations.map(l => `<a href="/admin/specials/day/${day}/location/${l.slug}" class="btn ${locationSlug === l.slug ? 'btn-primary' : 'btn-secondary'} btn-sm">${escHTML(l.name)}</a>`).join('')}
    </div>
  ` : '';

  const actionUrl = `/admin/specials/day/${day}${isOverride ? `/location/${locationSlug}` : ''}`;

  const specialsList = (specials || []).map((s, i) => `
    <div class="special-item" id="special-${s.id}" data-special-id="${s.id}" draggable="true">
      <div class="drag-handle" aria-label="Drag to reorder">\u22ee\u22ee</div>
      <div class="special-main">
        <div class="name">
          ${s.imageUrl ? `<img src="${escHTML(s.imageUrl)}" alt="" class="special-thumb" style="vertical-align:middle; margin-right:8px" />` : ''}
          ${escHTML(s.name)} <span class="muted">#${i + 1}</span>
          ${s.price ? ` <span class="price">${escHTML(s.price)}</span>` : ''}
        </div>
        ${s.description ? `<div class="desc">${escHTML(s.description)}</div>` : ''}
        <div style="display:flex; gap:4px; flex-wrap:wrap; margin-top:4px">
          ${s.isFeatured ? '<span class="tag" style="background:rgba(212,175,55,0.3); color:#d4af37">\u2605</span>' : ''}
          ${s.category ? `<span class="tag" style="background:rgba(212,175,55,0.15); color:#d4af37">${escHTML(s.category)}</span>` : ''}
          ${s.section ? `<span class="tag" style="background:rgba(183,115,51,0.15); color:#b87333">${escHTML(s.section)}</span>` : ''}
          ${s.badges ? escHTML(s.badges).split(',').map(b => `<span class="tag" style="background:rgba(212,175,55,0.15); color:#d4af37">${b.trim()}</span>`).join('') : ''}
        </div>
      </div>
      <div class="special-meta">
        <form method="POST" action="${actionUrl}" class="inline-form">
          <input type="hidden" name="_action" value="moveSpecial" />
          <input type="hidden" name="specialId" value="${s.id}" />
          <button type="submit" name="direction" value="up" class="btn btn-secondary btn-sm${i === 0 ? ' btn-disabled' : ''}" ${i === 0 ? 'disabled' : ''}>\u2191</button>
          <button type="submit" name="direction" value="down" class="btn btn-secondary btn-sm${i === specials.length - 1 ? ' btn-disabled' : ''}" ${i === specials.length - 1 ? 'disabled' : ''}>\u2193</button>
        </form>
        <button type="button" class="btn btn-secondary btn-sm" onclick="toggleEdit('${s.id}')">Edit</button>
        <form method="POST" action="${actionUrl}" style="display:inline">
          <input type="hidden" name="_action" value="duplicateSpecial" />
          <input type="hidden" name="specialId" value="${s.id}" />
          <button type="submit" class="btn btn-secondary btn-sm" title="Make a copy of this special">Copy</button>
        </form>
        <form method="POST" action="${actionUrl}" style="display:inline">
          <input type="hidden" name="_action" value="deleteSpecial" />
          <input type="hidden" name="specialId" value="${s.id}" />
          <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete &quot;${escHTML(s.name)}&quot;?')">Del</button>
        </form>
      </div>
    </div>
    <div class="edit-form-inline" id="edit-${s.id}" style="display:none">
      <form method="POST" action="${actionUrl}">
        <input type="hidden" name="_action" value="editSpecial" />
        <input type="hidden" name="specialId" value="${s.id}" />
        <div class="form-row">
          <div><label>Name</label><input type="text" name="specialName" value="${escHTML(s.name)}" required /></div>
          <div><label>Price</label><input type="text" name="specialPrice" value="${escHTML(s.price)}" /></div>
        </div>
        <label>Description</label>
        <input type="text" name="specialDescription" value="${escHTML(s.description)}" placeholder="Short description" />
        <label>Detail Text</label>
        <textarea name="specialDetailText" placeholder="Longer sell copy / tasting notes">${escHTML(s.detailText)}</textarea>
        <div class="form-row">
          <div><label>Section</label><input type="text" name="specialSection" value="${escHTML(s.section)}" placeholder="e.g. $8 Cocktails" /></div>
          <div><label>Badges</label><input type="text" name="specialBadges" value="${escHTML(s.badges)}" placeholder="e.g. New, Staff Pick" /></div>
        </div>
        <div class="form-row">
          <div><label>Time Window</label><input type="text" name="specialTimeWindow" value="${escHTML(s.timeWindow)}" placeholder="e.g. Until 7 PM" /></div>
          <div><label>Category</label><select name="specialCategory">${buildCategoryOptions(s.category, categoryOptions)}</select></div>
          <div><label>Order</label><input type="number" name="specialOrder" value="${s.displayOrder}" /></div>
        </div>
        <label>Image</label>
        ${imageUploadWidget({ name: 'specialImageUrl', prefix: `sp-img-${s.id}`, value: s.imageUrl || '' })}
        <label style="display:flex; align-items:center; gap:8px; margin-top:8px">
          <input type="checkbox" name="specialFeatured" ${s.isFeatured ? 'checked' : ''} style="width:auto" />
          <span>Featured (gold highlight)</span>
        </label>
        <div class="form-actions">
          <button type="submit" class="btn btn-primary btn-sm">Save</button>
          <button type="button" class="btn btn-secondary btn-sm" onclick="toggleEdit('${s.id}')">Cancel</button>
        </div>
      </form>
    </div>
  `).join('');

  return adminLayout(`${DAY_LABELS[day]} Theme`, `
    <div class="page-header">
      <div>
        <div class="admin-kicker">${isOverride && loc ? escHTML(loc.name) : 'Company default'}</div>
        <h1>${DAY_LABELS[day]}${isOverride && loc ? ` Specials for ${escHTML(loc.name)}` : ' Specials'}</h1>
        <p class="page-subtitle">${isOverride ? 'Location-specific programming and discounted spirit selection.' : 'Company default theme and specials for this day.'}</p>
      </div>
      <div class="page-actions">
        <a href="/admin/specials" class="btn btn-secondary btn-sm">Weekly Overview</a>
      </div>
    </div>
    ${message ? `<div class="alert ${message.type === 'error' ? 'alert-error' : 'alert-success'}">${message.text}</div>` : ''}
    ${overrideTabs}

    <section class="form-section">
      <div class="form-section-head">
        <div>
          <h2>Theme Details</h2>
          <p>This headline and copy appear at the top of the public daily specials page.</p>
        </div>
      </div>
      <div class="form-section-body">
      <form method="POST" action="/admin/specials/day/${day}${isOverride ? `/location/${locationSlug}` : ''}" data-autosave="special-theme-${day}${isOverride ? '-' + escHTML(locationSlug) : '-default'}">
        <input type="hidden" name="_action" value="saveTheme" />
        <label>Theme Name</label>
        <input type="text" name="name" value="${escHTML(theme ? theme.name : '')}" required placeholder="e.g. Industry Night" />
        <label>Tagline</label>
        <input type="text" name="tagline" value="${escHTML(theme ? theme.tagline : '')}" placeholder="e.g. We take care of our own" />
        <label>Description</label>
        <textarea name="description" placeholder="Optional longer description">${escHTML(theme ? theme.description : '')}</textarea>
        <label>Theme Color <span style="font-weight:400; color:#888; font-size:0.8rem">(optional &mdash; tints the public specials header for this day)</span></label>
        <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap">
          <input type="color" name="themeColor" value="${escHTML(theme && theme.themeColor ? theme.themeColor : '#d4af37')}" style="width:60px; height:42px; padding:2px; cursor:pointer" />
          <span style="color:#888; font-size:0.82rem">Click swatch to choose &mdash; default is brand gold</span>
        </div>
        <label style="display:flex; align-items:center; gap:8px; margin-top:16px">
          <input type="checkbox" name="isActive" ${!theme || theme.isActive ? 'checked' : ''} style="width:auto" />
          <span>Active</span>
        </label>
        <div class="form-actions">
          <button type="submit" class="btn btn-primary">Save Theme</button>
          ${theme ? `
            <button type="submit" name="_action" value="deleteTheme" class="btn btn-danger" onclick="return confirm('Delete this theme and all its specials?')">Delete Theme</button>
          ` : ''}
        </div>
      </form>
      </div>
    </section>

    ${day === 'SUNDAY' && theme ? `
    <div class="admin-help">
      <h2>Break Even Bottles</h2>
      <p style="color:#ccc; line-height:1.6; margin-bottom:12px">Sunday bottles are managed through the <strong>Bartender Dashboard</strong>, not here. To update this week's bottles:</p>
      <ol style="color:#aaa; line-height:1.8; padding-left:20px; margin-bottom:12px">
        <li>Log in to the <a href="https://bartender.apps.dramanddraught.com" target="_blank" style="color:#d4af37">Bartender Dashboard</a></li>
        <li>Go to <strong>Break Even Bottles</strong> in the sidebar</li>
        <li>Select the location and set this week's bottles</li>
        <li>Mark them as <strong>Active</strong> &mdash; they'll appear on the public page automatically</li>
      </ol>
      <p style="color:#888; font-size:0.85rem">The public specials page pulls bottles directly from the dashboard each week. No changes needed here.</p>
    </div>
    ` : ''}

    ${!isOverride ? `
    <div class="admin-help">
      <h2>Discounted Spirits</h2>
      <p style="color:#aaa">Configure a discounted spirit selection for this day (e.g. half-price whiskey). Selections are configured per location since inventory and pricing differ. Select a location tab above to configure.</p>
    </div>
    ` : ''}
    ${isOverride && (halfPriceTheme || theme) ? renderHalfPricePicker(day, halfPriceTheme || theme, actionUrl, spiritCatalog, spiritCategories) : ''}

    ${theme ? `
    <section class="form-section">
      <div class="form-section-head">
        <div>
          <h2>Specials</h2>
          <p>Add the public offers guests should see for ${DAY_LABELS[day]}. Drag to reorder, then save order.</p>
        </div>
      </div>
      <div class="form-section-body">

      <div class="add-special-box">
        <h3 style="margin-top:0">Add Special</h3>
        <form method="POST" action="${actionUrl}" data-autosave="special-add-${day}${isOverride ? '-' + escHTML(locationSlug) : '-default'}">
          <input type="hidden" name="_action" value="addSpecial" />
          <div class="form-row">
            <div>
              <label>Name</label>
              <input type="text" name="specialName" required placeholder="e.g. Well Cocktails" />
            </div>
            <div>
              <label>Price</label>
              <input type="text" name="specialPrice" placeholder="e.g. $5, 50% off" />
            </div>
          </div>
          <label>Description</label>
          <input type="text" name="specialDescription" placeholder="Short description" />
          <label>Detail Text</label>
          <textarea name="specialDetailText" placeholder="Longer sell copy / tasting notes"></textarea>
          <div class="form-row">
            <div>
              <label>Section</label>
              <input type="text" name="specialSection" placeholder="e.g. $8 Cocktails" />
            </div>
            <div>
              <label>Badges</label>
              <input type="text" name="specialBadges" placeholder="e.g. New, Staff Pick" />
            </div>
          </div>
          <div class="form-row">
            <div>
              <label>Time Window</label>
              <input type="text" name="specialTimeWindow" placeholder="e.g. Until 7 PM" />
            </div>
            <div>
              <label>Category</label>
              <select name="specialCategory">${buildCategoryOptions('', categoryOptions)}</select>
            </div>
            <div>
              <label>Display Order</label>
              <input type="number" name="specialOrder" value="${(specials || []).length}" />
            </div>
          </div>
          <label>Image</label>
          ${imageUploadWidget({ name: 'specialImageUrl', prefix: `sp-add-${day}`, value: '' })}
          <label style="display:flex; align-items:center; gap:8px; margin-top:8px">
            <input type="checkbox" name="specialFeatured" style="width:auto" />
            <span>Featured (gold highlight)</span>
          </label>
          <div class="form-actions">
            <button type="submit" class="btn btn-primary">Add Special</button>
          </div>
        </form>
      </div>

      ${specialsList ? `
        <div class="special-controls">
          <form id="reorderForm" method="POST" action="${actionUrl}" class="inline-form">
            <input type="hidden" name="_action" value="reorderSpecials" />
            <input type="hidden" name="specialOrderPayload" id="specialOrderPayload" value="" />
            <button type="submit" class="btn btn-secondary btn-sm">Save order</button>
          </form>
          <form id="bulkCategoryForm" method="POST" action="${actionUrl}" class="inline-form">
            <input type="hidden" name="_action" value="setSpecialCategoryBulk" />
            <select name="specialCategory">${buildCategoryOptions('', categoryOptions)}</select>
            <button type="submit" class="btn btn-secondary btn-sm">Apply category to selected</button>
            <span class="muted count" id="selectedSpecialCount">0 selected</span>
          </form>
        </div>
        <div id="specialsList" class="specials-list">
          ${specialsList}
        </div>
      ` : '<p class="empty-state">No specials yet. Add one above.</p>'}
      </div>
    </section>
    ` : ''}

    <script>
      function refreshSpecialOrderState() {
        const container = document.getElementById('specialsList');
        if (!container) return;

        const items = Array.from(container.querySelectorAll('.special-item'));
        items.forEach((item, index) => {
          item.dataset.orderIndex = String(index);
          var orderBadge = item.querySelector('.name .muted');
          if (orderBadge) orderBadge.textContent = '#' + (index + 1);
        });

        const payload = JSON.stringify(items.map((item) => item.dataset.specialId).filter(Boolean));
        var payloadEl = document.getElementById('specialOrderPayload');
        if (payloadEl) payloadEl.value = payload;

        var selectedCountEl = document.getElementById('selectedSpecialCount');
        if (selectedCountEl) {
          const selectedCount = items.filter((item) => {
            const checkbox = item.querySelector('input[type="checkbox"][form="bulkCategoryForm"]');
            return checkbox && checkbox.checked;
          }).length;
          selectedCountEl.textContent = selectedCount + ' selected';
        }
      }

      function getReorderList() {
        return document.getElementById('specialsList');
      }

      function initializeSpecialDragAndDrop() {
        var container = getReorderList();
        if (!container) return;

        var draggedItem = null;
        var items = Array.from(container.querySelectorAll('.special-item'));

        items.forEach((item) => {
          item.setAttribute('draggable', 'true');
          item.addEventListener('dragstart', function(event) {
            draggedItem = event.currentTarget;
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/plain', draggedItem.dataset.specialId || '');
            event.currentTarget.classList.add('dragging');
          });

          item.addEventListener('dragend', function(event) {
            event.currentTarget.classList.remove('dragging');
            refreshSpecialOrderState();
            draggedItem = null;
          });

          item.addEventListener('dragover', function(event) {
            event.preventDefault();
            event.dataTransfer.dropEffect = 'move';
            const target = event.currentTarget;
            const bounds = target.getBoundingClientRect();
            const offset = event.clientY - bounds.top;
            if (draggedItem && target !== draggedItem) {
              if (offset < bounds.height / 2) {
                container.insertBefore(draggedItem, target);
              } else {
                container.insertBefore(draggedItem, target.nextSibling);
              }
            }
          });
        });
      }

      function toggleEdit(id) {
        var el = document.getElementById('edit-' + id);
        if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
      }

      initializeSpecialDragAndDrop();
      refreshSpecialOrderState();
      ${imageUploadWidgetScript()}
    </script>
    <style>${imageUploadWidgetCss()}</style>
  `, user, { pathname: '/admin/specials', flashMsg });
}

function buildFlightNewUrl(month, year, locationSlug = '', copyFromId = '') {
  const params = new URLSearchParams();
  if (month) params.set('month', String(month));
  if (year) params.set('year', String(year));
  if (locationSlug) params.set('location', String(locationSlug));
  if (copyFromId) params.set('copyFrom', String(copyFromId));
  const query = params.toString();
  return `/admin/flights/new${query ? `?${query}` : ''}`;
}

function getFlightScopeLabel(flight) {
  return flight && flight.location ? flight.location.name : 'Company Default';
}

function getFlightScopeSlug(flight) {
  return flight && flight.location ? String(flight.location.slug || '') : '';
}

// ─── Flights List ───
function flightsList(flights, locations, user, flashMsg) {
  const groups = new Map();
  (flights || []).forEach((flight) => {
    const key = `${flight.year}-${flight.month}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(flight);
  });

  const rows = Array.from(groups.values()).map((entries) => {
    const variants = [...entries];
    const sample = variants[0];
    const companyDefault = variants.find((entry) => !entry.locationId) || null;
    const overrides = variants.filter((entry) => !!entry.locationId);
    const manageTarget = companyDefault || overrides[0] || null;
    const missingLocations = (locations || []).filter((location) => !overrides.some((entry) => entry.locationId === location.id));

    const defaultCell = companyDefault
      ? `
        <div><a href="/admin/flights/${companyDefault.id}">${escHTML(companyDefault.theme)}</a></div>
        <div style="color:#888; font-size:0.9rem; margin-top:4px">
          ${escHTML(companyDefault.price || 'Price not set')} • ${companyDefault.pours.length} pour${companyDefault.pours.length !== 1 ? 's' : ''}
          <span class="tag ${companyDefault.isActive ? 'tag-active' : 'tag-inactive'}" style="margin-left:8px">${companyDefault.isActive ? 'Active' : 'Inactive'}</span>
        </div>
      `
      : `
        <div style="color:#888">No company default yet.</div>
        <div style="margin-top:8px">
          <a href="${buildFlightNewUrl(sample.month, sample.year, '', manageTarget ? manageTarget.id : '')}" class="btn btn-secondary btn-sm">Create Shared Default</a>
        </div>
      `;

    const overridesCell = overrides.length > 0
      ? `
        <div style="display:flex; gap:8px; flex-wrap:wrap">
          ${overrides.map((entry) => `
            <a href="/admin/flights/${entry.id}" class="btn btn-secondary btn-sm">${escHTML(getFlightScopeLabel(entry))}</a>
          `).join('')}
        </div>
        ${companyDefault && missingLocations.length > 0 ? `
          <div style="color:#888; font-size:0.85rem; margin-top:8px">
            ${missingLocations.length} location${missingLocations.length !== 1 ? 's' : ''} still use the company default.
          </div>
        ` : ''}
      `
      : `
        <div style="color:#888">No location overrides. All locations use the company default.</div>
        ${companyDefault && missingLocations.length > 0 ? `
          <div style="margin-top:8px; display:flex; gap:8px; flex-wrap:wrap">
            ${missingLocations.slice(0, 3).map((location) => `
              <a href="${buildFlightNewUrl(sample.month, sample.year, location.slug, companyDefault.id)}" class="btn btn-secondary btn-sm">Override ${escHTML(location.name)}</a>
            `).join('')}
            ${missingLocations.length > 3 ? `<span style="color:#888; font-size:0.85rem">+${missingLocations.length - 3} more in editor</span>` : ''}
          </div>
        ` : ''}
      `;

    return `
      <tr>
        <td>${MONTHS[sample.month]} ${sample.year}</td>
        <td>${defaultCell}</td>
        <td>${overridesCell}</td>
        <td>${manageTarget ? `<a href="/admin/flights/${manageTarget.id}" class="btn btn-secondary btn-sm">Manage</a>` : `<a href="${buildFlightNewUrl(sample.month, sample.year)}" class="btn btn-secondary btn-sm">Create</a>`}</td>
      </tr>
    `;
  }).join('');

  return adminLayout('Flights', `
    <div class="page-header">
      <div>
        <div class="admin-kicker">Monthly flight builder</div>
        <h1>Tasting Flights</h1>
        <p class="page-subtitle">Set a company default for the month, then create location overrides only when a bar needs a different lineup.</p>
      </div>
      <a href="/admin/flights/new" class="btn btn-primary">New Flight</a>
    </div>
    ${flights.length === 0 ? '<div class="empty-state">No flights yet. Create one to get started.</div>' : `
      <table>
        <thead><tr><th>Month</th><th>Company Default</th><th>Location Overrides</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `}
  `, user, { pathname: '/admin/flights', flashMsg });
}

// ─── Flight Editor ───
function flightEditor(flight, isNew, user, message, flashMsg, options = {}) {
  const locations = options.locations || [];
  const relatedFlights = options.relatedFlights || [];
  const selectedLocationSlug = options.selectedLocationSlug || getFlightScopeSlug(flight);
  const selectedLocation = selectedLocationSlug ? locations.find((location) => location.slug === selectedLocationSlug) : null;
  const pours = flight && Array.isArray(flight.pours) ? [...flight.pours].sort((a, b) => a.displayOrder - b.displayOrder) : [];
  const now = new Date();
  const defaultMonth = flight ? flight.month : now.getMonth() + 1;
  const defaultYear = flight ? flight.year : now.getFullYear();
  const companyDefault = relatedFlights.find((entry) => !entry.locationId) || null;
  const currentScopeSlug = selectedLocation ? selectedLocation.slug : getFlightScopeSlug(flight);
  const isOverride = !!currentScopeSlug;
  const copySource = options.copySource || null;
  const copySourceId = isNew ? (copySource ? copySource.id : '') : (flight ? flight.id : '');

  const monthOptions = Array.from({ length: 12 }, (_, i) => `<option value="${i + 1}" ${defaultMonth === i + 1 ? 'selected' : ''}>${MONTHS[i + 1]}</option>`).join('');
  const yearOptions = Array.from({ length: 3 }, (_, i) => {
    const y = now.getFullYear() + i - 1;
    return `<option value="${y}" ${defaultYear === y ? 'selected' : ''}>${y}</option>`;
  }).join('');

  const scopeOptions = [
    `<option value=""${!selectedLocation ? ' selected' : ''}>Company Default</option>`,
    ...locations.map((location) => `<option value="${escHTML(location.slug)}"${selectedLocation && selectedLocation.slug === location.slug ? ' selected' : ''}>${escHTML(location.name)}</option>`),
  ].join('');

  const tabs = locations.length > 0 ? `
    <div style="margin-bottom:20px; display:flex; gap:8px; flex-wrap:wrap">
      <a href="${companyDefault ? `/admin/flights/${companyDefault.id}` : buildFlightNewUrl(defaultMonth, defaultYear, '', copySourceId)}" class="btn ${!currentScopeSlug ? 'btn-primary' : 'btn-secondary'} btn-sm">Company Default${companyDefault ? '' : ' +'}</a>
      ${locations.map((location) => {
        const existing = relatedFlights.find((entry) => getFlightScopeSlug(entry) === location.slug) || null;
        const href = existing ? `/admin/flights/${existing.id}` : buildFlightNewUrl(defaultMonth, defaultYear, location.slug, copySourceId || (companyDefault ? companyDefault.id : ''));
        const label = `${escHTML(location.name)}${existing ? '' : ' +'}`;
        return `<a href="${href}" class="btn ${currentScopeSlug === location.slug ? 'btn-primary' : 'btn-secondary'} btn-sm">${label}</a>`;
      }).join('')}
    </div>
    <p style="color:#888; font-size:0.85rem; margin-top:-8px; margin-bottom:16px">Tabs marked with <strong>+</strong> create a copy for that location so you can swap a product without changing everyone else.</p>
  ` : '';

  const scopeSummary = selectedLocation
    ? `This override only affects ${escHTML(selectedLocation.name)}. Delete it any time to fall back to the company default.`
    : 'This is the shared flight for every location that does not have its own override.';

  const copyNote = copySource
    ? `
      <div class="card" style="background:rgba(212,175,55,0.08); border:1px solid rgba(212,175,55,0.18)">
        <strong>Prefilled from ${escHTML(getFlightScopeLabel(copySource))}.</strong>
        <div style="color:#888; margin-top:6px">You can change pours, price, or description before saving this ${selectedLocation ? 'location override' : 'company default'}.</div>
      </div>
    `
    : '';

  const scopeField = isNew ? `
    <label>Applies To</label>
    <select name="locationSlug">${scopeOptions}</select>
    <p style="color:#888; font-size:0.85rem; margin-top:8px">Use Company Default when most locations share the same flight. Create a location override only when one bar needs different pours.</p>
  ` : `
    <label>Applies To</label>
    <div style="margin-top:8px">
      <span class="tag" style="background:rgba(212,175,55,0.15); color:#d4af37">${escHTML(selectedLocation ? selectedLocation.name : 'Company Default')}</span>
    </div>
    <p style="color:#888; font-size:0.85rem; margin-top:8px">${scopeSummary}</p>
  `;

  const pourFields = [0, 1, 2].map((i) => {
    const p = pours[i] || {};
    return `
      <div class="card">
        <h3>Pour ${i + 1}</h3>
        <label>Name</label>
        <input type="text" name="pour${i}_name" value="${escHTML(p.spiritName)}" ${i === 0 ? 'required' : ''} placeholder="e.g. Westward Single Malt, Pinot Grigio, Espresso Martini" />
        <label>Pour Size</label>
        <input type="text" name="pour${i}_size" value="${escHTML(p.pourSize)}" placeholder="e.g. 1 oz" />
        <label>Description</label>
        <input type="text" name="pour${i}_desc" value="${escHTML(p.description)}" placeholder="e.g. Portland, Oregon — or grape varietal, cocktail style" />
      </div>
    `;
  }).join('');

  const deleteLabel = isOverride ? 'Delete Override' : 'Delete Flight';
  const deleteConfirm = isOverride
    ? 'Delete this override and fall back to the company default for this location?'
    : 'Delete this flight?';

  return adminLayout(isNew ? 'New Flight' : 'Edit Flight', `
    <div class="page-header">
      <div>
        <div class="admin-kicker">${isOverride ? 'Location override' : 'Company default'}</div>
        <h1>${isNew ? 'Create Flight' : 'Edit Flight'}</h1>
        <p class="page-subtitle">${scopeSummary}</p>
      </div>
      <div class="page-actions">
        <a href="/admin/flights" class="btn btn-secondary">All Flights</a>
      </div>
    </div>
    ${message ? `<div class="alert ${message.type === 'error' ? 'alert-error' : 'alert-success'}">${message.text}</div>` : ''}
    ${tabs}
    ${copyNote}
    <form method="POST" action="/admin/flights/${isNew ? 'new' : flight.id}">
      <section class="form-section">
        <div class="form-section-head">
          <div>
            <h2>Flight Details</h2>
            <p>Choose where this flight applies, the public theme, month, year, and price.</p>
          </div>
        </div>
        <div class="form-section-body">
        ${scopeField}
        <label>Theme</label>
        <input type="text" name="theme" value="${escHTML(flight ? flight.theme : '')}" required placeholder="e.g. American Single Malts" />
        <label>Description</label>
        <textarea name="description" placeholder="Optional description of the flight theme">${escHTML(flight ? flight.description : '')}</textarea>
        <div class="form-row">
          <div>
            <label>Month</label>
            <select name="month">${monthOptions}</select>
          </div>
          <div>
            <label>Year</label>
            <select name="year">${yearOptions}</select>
          </div>
          <div>
            <label>Price</label>
            <input type="text" name="price" value="${escHTML(flight ? flight.price : '$15')}" placeholder="e.g. $15" />
          </div>
        </div>
        <label style="display:flex; align-items:center; gap:8px; margin-top:16px">
          <input type="checkbox" name="isActive" ${!flight || flight.isActive ? 'checked' : ''} style="width:auto" />
          <span>Active</span>
        </label>
        </div>
      </section>
      <div class="section-head">
        <div>
          <h2>Pours</h2>
          <p>Add up to three pours. The first pour is required.</p>
        </div>
      </div>
      ${pourFields}
      <div class="sticky-actions">
        <button type="submit" class="btn btn-primary">${isNew ? 'Create Flight' : 'Save Changes'}</button>
        ${!isNew ? `<button type="submit" name="_action" value="delete" class="btn btn-danger" onclick="return confirm('${deleteConfirm}')">${deleteLabel}</button>` : ''}
        <a href="/admin/flights" class="btn btn-secondary">Cancel</a>
      </div>
    </form>
  `, user, { pathname: '/admin/flights', flashMsg });
}

// ─── Bottles List ───
function bottlesList(bottles, user, flashMsg) {
  const rows = bottles.map(b => `
    <tr>
      <td><a href="/admin/bottles/${b.id}">${escHTML(b.name)}</a></td>
      <td>${MONTHS[b.month]} ${b.year}</td>
      <td>${escHTML(b.category || '-')}</td>
      <td style="color:#d4af37; font-weight:700">${escHTML(b.costPrice)}</td>
      <td style="color:#666; text-decoration:line-through">${escHTML(b.regularPrice || '-')}</td>
      <td><span class="tag ${b.isActive ? 'tag-active' : 'tag-inactive'}">${b.isActive ? 'Active' : 'Inactive'}</span></td>
      <td><a href="/admin/bottles/${b.id}" class="btn btn-secondary btn-sm">Edit</a></td>
    </tr>
  `).join('');

  return adminLayout('Sunday Bottles', `
    <div class="page-header">
      <div>
        <div class="admin-kicker">Sunday specials</div>
        <h1>Sunday Break Even Bottles</h1>
        <p class="page-subtitle">Featured bottles sold at cost on Sundays.</p>
      </div>
      <a href="/admin/bottles/new" class="btn btn-primary">New Bottle</a>
    </div>
    ${bottles.length === 0 ? '<div class="empty-state">No bottles yet. Add one to get started.</div>' : `
      <table>
        <thead><tr><th>Name</th><th>Month</th><th>Category</th><th>Cost Price</th><th>Regular</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `}
  `, user, { pathname: '/admin/bottles', flashMsg });
}

// ─── Bottle Editor ───
function bottleEditor(bottle, isNew, user, message, flashMsg) {
  const now = new Date();
  const defaultMonth = bottle ? bottle.month : now.getMonth() + 1;
  const defaultYear = bottle ? bottle.year : now.getFullYear();

  const monthOptions = Array.from({length: 12}, (_, i) => `<option value="${i+1}" ${defaultMonth === i+1 ? 'selected' : ''}>${MONTHS[i+1]}</option>`).join('');
  const yearOptions = Array.from({length: 3}, (_, i) => {
    const y = now.getFullYear() + i - 1;
    return `<option value="${y}" ${defaultYear === y ? 'selected' : ''}>${y}</option>`;
  }).join('');

  const catOptions = ['', 'bourbon', 'scotch', 'rye', 'irish', 'japanese', 'rum', 'tequila', 'mezcal', 'gin', 'vodka', 'other'].map(c =>
    `<option value="${c}" ${(bottle && bottle.category === c) ? 'selected' : ''}>${c ? c.charAt(0).toUpperCase() + c.slice(1) : 'None'}</option>`
  ).join('');

  return adminLayout(isNew ? 'New Bottle' : 'Edit Bottle', `
    <div class="page-header">
      <div>
        <div class="admin-kicker">Break even bottle</div>
        <h1>${isNew ? 'Add Bottle' : 'Edit Bottle'}</h1>
        <p class="page-subtitle">Set the bottle, cost price, month, and publishing status.</p>
      </div>
      <div class="page-actions"><a href="/admin/bottles" class="btn btn-secondary">All Bottles</a></div>
    </div>
    ${message ? `<div class="alert ${message.type === 'error' ? 'alert-error' : 'alert-success'}">${message.text}</div>` : ''}
    <form method="POST" action="/admin/bottles/${isNew ? 'new' : bottle.id}">
      <section class="form-section">
        <div class="form-section-head">
          <div>
            <h2>Bottle Details</h2>
            <p>Guests see active bottles for the selected month on the Sunday specials page.</p>
          </div>
        </div>
        <div class="form-section-body">
        <label>Bottle Name</label>
        <input type="text" name="name" value="${escHTML(bottle ? bottle.name : '')}" required placeholder="e.g. Buffalo Trace Bourbon" />
        <label>Description</label>
        <textarea name="description" placeholder="Optional description">${escHTML(bottle ? bottle.description : '')}</textarea>
        <div class="form-row">
          <div>
            <label>Cost Price (Break Even)</label>
            <input type="text" name="costPrice" value="${escHTML(bottle ? bottle.costPrice : '')}" required placeholder="e.g. $25" />
          </div>
          <div>
            <label>Regular Price</label>
            <input type="text" name="regularPrice" value="${escHTML(bottle ? bottle.regularPrice : '')}" placeholder="e.g. $45" />
          </div>
        </div>
        <div class="form-row">
          <div>
            <label>Month</label>
            <select name="month">${monthOptions}</select>
          </div>
          <div>
            <label>Year</label>
            <select name="year">${yearOptions}</select>
          </div>
          <div>
            <label>Category</label>
            <select name="category">${catOptions}</select>
          </div>
        </div>
        <div class="form-row">
          <div>
            <label>Display Order</label>
            <input type="number" name="displayOrder" value="${bottle ? bottle.displayOrder : 0}" />
          </div>
        </div>
        <label style="display:flex; align-items:center; gap:8px; margin-top:16px">
          <input type="checkbox" name="isActive" ${!bottle || bottle.isActive ? 'checked' : ''} style="width:auto" />
          <span>Active</span>
        </label>
        </div>
      </section>
      <div class="sticky-actions">
        <button type="submit" class="btn btn-primary">${isNew ? 'Add Bottle' : 'Save Changes'}</button>
        ${!isNew ? `<button type="submit" name="_action" value="delete" class="btn btn-danger" onclick="return confirm('Delete this bottle?')">Delete</button>` : ''}
        <a href="/admin/bottles" class="btn btn-secondary">Cancel</a>
      </div>
    </form>
  `, user, { pathname: '/admin/bottles', flashMsg });
}

module.exports = { specialsDashboard, dayThemeEditor, flightsList, flightEditor, bottlesList, bottleEditor, DAYS, DAY_LABELS, MONTHS };
