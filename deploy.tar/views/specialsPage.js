const DAYS_ORDER = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
const DAY_SHORT = { MONDAY: 'Mon', TUESDAY: 'Tue', WEDNESDAY: 'Wed', THURSDAY: 'Thu', FRIDAY: 'Fri', SATURDAY: 'Sat', SUNDAY: 'Sun' };
const DAY_LABELS = { MONDAY: 'Monday', TUESDAY: 'Tuesday', WEDNESDAY: 'Wednesday', THURSDAY: 'Thursday', FRIDAY: 'Friday', SATURDAY: 'Saturday', SUNDAY: 'Sunday' };

function getEasternDay() {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  return { dayOfWeek: days[now.getDay()], dayLabel: DAY_LABELS[days[now.getDay()]], date: now };
}

function getEasternMonth() {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
  return { month: now.getMonth() + 1, year: now.getFullYear() };
}

function escHTML(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function groupBySection(specials) {
  const groups = [];
  const map = {};
  for (const s of specials) {
    const key = s.section || '';
    if (!map[key]) {
      map[key] = [];
      groups.push({ section: key, items: map[key] });
    }
    map[key].push(s);
  }
  return groups;
}

function sectionKeyForFilter(section) {
  return String(section || 'all')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function getTodayHours(location, dayOfWeek) {
  if (!location.hours) return null;
  const key = dayOfWeek.toLowerCase();
  return location.hours[key] || null;
}

function formatGuestCharge(priceText) {
  if (!priceText) return null;
  const cleaned = String(priceText).trim().replace(/\s*\/\s*oz\b/i, '').trim();
  if (!cleaned) return null;
  return cleaned.startsWith('$') ? cleaned : `$${cleaned}`;
}

function sanitizeGuestCopy(text) {
  if (!text) return '';
  const cleaned = String(text)
    .replace(/\s*—\s*40\+\s*options\s+available\s+via\s+qr\s*code\.?/gi, '')
    .replace(/\s*-\s*40\+\s*options\s+available\s+via\s+qr\s*code\.?/gi, '')
    .replace(/service\s+industry\s+workers?\s+get\s+special\s+pricing\s+all\s+night\.?/gi, '')
    .replace(/explore\s+our\s+collection\s+of\s+300\+\s+whiskeys\s+with\s+special\s+wed.*?pricing\.?/gi, '')
    .replace(/rotating\s+themed\s+3[- ]pour\s+flights\.?\s+a?\s*guided\s+journey\s+through\s+fine\s+spirits\.?/gi, '')
    .replace(/great\s+deals\s+to\s+kick\s+off\s+the\s+weekend\s+a\s+day\s+early\.?/gi, '')
    .replace(/select\s+bottles\s+sold\s+at\s+cost\s+—\s*check\s+with\s+your\s+bartender\s+for\s+this\s+month['’]s\s+selection\.?/gi, '')
    .replace(/select\s+bottles\s+sold\s+at\s+cost\s+check\s+with\s+your\s+bartender\s+for\s+this\s+month['’]s\s+selection\.?/gi, '')
    .replace(/—+\s*$/, '')
    .replace(/^\s*—+\s*/, '')
    .trim();
  return cleaned.replace(/\s{2,}/g, ' ');
}

function fallbackBottleNoteSections(rawNotes) {
  if (!rawNotes || typeof rawNotes !== 'string') return [];
  return rawNotes
    .replace(/\r/g, '')
    .split(/\n+|;| \| /)
    .map((part) => part.trim())
    .filter(Boolean)
    .slice(0, 5)
    .map((part, i) => {
      if (part.includes(':')) {
        const idx = part.indexOf(':');
        return { label: part.slice(0, idx).trim() || `Note ${i + 1}`, text: part.slice(idx + 1).trim() };
      }
      return { label: 'Tasting note', text: part };
    })
    .filter((entry) => entry.text);
}

function renderBottleTastingNotes(bottle) {
  const notes = bottle && bottle.guestNotes ? bottle.guestNotes : null;
  const list = notes && Array.isArray(notes.notes)
    ? notes.notes
    : fallbackBottleNoteSections(bottle && bottle.notes);

  const summary = notes && notes.summary ? notes.summary : 'Tasting notes';
  if (!list.length) return '';

  const rendered = list.map((item) => `
      <li class="bottle-note-item">
        <span class="bottle-note-label">${escHTML(item.label || 'Tasting note')}</span>
        <span class="bottle-note-text">${escHTML(item.text || '')}</span>
      </li>
    `).join('');

  return `
      <div class="bottle-note-block">
        <p class="bottle-note-summary">${escHTML(summary)}</p>
        <ul class="bottle-note-list">
          ${rendered}
        </ul>
      </div>
    `;
}

function makeQuery(day, todayDay) {
  const parts = [];
  if (day && day !== todayDay) parts.push(`day=${day}`);
  return parts.length ? `?${parts.join('&')}` : '';
}

function generateSpecialsPage(location, theme, specials, flight, bottles, viewingDay, tomorrowTheme, fridayFlight, options = {}) {
  const todayDay = getEasternDay().dayOfWeek;
  const activeDay = viewingDay || todayDay;
  const dayLabel = DAY_LABELS[activeDay];
  const isToday = activeDay === todayDay;
  const isFriday = activeDay === 'FRIDAY';
  const isSunday = activeDay === 'SUNDAY';
  const isMonday = activeDay === 'MONDAY';
  const themeTagline = sanitizeGuestCopy(theme && typeof theme.tagline === 'string' ? theme.tagline : '');
  const isIndustryNight = isMonday && theme && /industry night/i.test(theme.name || '');
  const badIndustryTagline = /we take care of our own/i;
  const shouldHideIndustryNightTagline = isIndustryNight && (themeTagline.toLowerCase() === '' || badIndustryTagline.test(themeTagline));
  const displayTagline = shouldHideIndustryNightTagline ? '' : themeTagline;
  const nextAvailable = options.nextAvailable || null;
  const warnings = options.warnings || {};
  const themeDescription = sanitizeGuestCopy(theme && typeof theme.description === 'string' ? theme.description : '');
  const hasGiftToYouCopy = /our gift to you/i.test(themeDescription);
  const showGiftToYouSubtitle = isSunday && bottles && bottles.length > 0 && !hasGiftToYouCopy;
  const isSundayBottlesDay = isSunday && (bottles || []).length > 0;
  const isBreakEvenSpecial = (s) => /break even/i.test(`${s && (s.name || '')} ${s && (s.section || '')} ${s && (s.description || '')}`);
  const specialsForDisplay = isSundayBottlesDay ? (specials || []).filter((s) => !isBreakEvenSpecial(s)) : (specials || []);
  const showThemeDescInBanner = theme && specialsForDisplay.length > 0;
  const sections = groupBySection(specialsForDisplay);
  const hasSections = sections.some(g => g.section !== '');
  const sectionFilters = [];
  const sectionSeen = new Set();
  for (const sectionGroup of sections) {
    if (!sectionGroup.section) continue;
    const key = sectionKeyForFilter(sectionGroup.section);
    if (!sectionSeen.has(key)) {
      sectionSeen.add(key);
      sectionFilters.push({ label: sectionGroup.section, key });
    }
  }
  const sectionFilterMarkup = sectionFilters.length > 1 ? `
    <div class="filter-chips" role="tablist" aria-label="Filter cocktail categories">
      <button class="filter-chip is-active" data-section-filter="all" type="button">All</button>
      ${sectionFilters.map((filter) => `<button class="filter-chip" data-section-filter="${escHTML(filter.key)}" type="button">${escHTML(filter.label)}</button>`).join('')}
    </div>
  ` : '';

  const spiritListUrl = `https://public.apps.dramanddraught.com/spirits/${location.slug}`;

  // Today's hours
  const todayHours = getTodayHours(location, activeDay);

  // Day navigation tabs
  const dayNav = DAYS_ORDER.map(d => {
    const isCurrent = d === activeDay;
    const isActualToday = d === todayDay;
    const href = `/${location.slug}/specials${makeQuery(d, todayDay)}`;
    return `<a href="${href}" class="day-tab${isCurrent ? ' active' : ''}${isActualToday ? ' today' : ''}" aria-label="View ${DAY_SHORT[d]} specials">${DAY_SHORT[d]}</a>`;
  }).join('');

  // Search + filter controls
  const searchSectionUI = specialsForDisplay.length ? `
    <div class="section">
      <div class="section-header">
        <h2>Search this lineup</h2>
      </div>
      <div class="cocktail-search" id="cocktail-search-wrap">
        <input id="cocktail-search-input" type="search" placeholder="Search cocktails, ingredients, or notes" aria-label="Search specials">
        <button id="cocktail-clear-filters" type="button" class="filter-reset">Clear filters</button>
      </div>
      ${sectionFilterMarkup}
      <div id="cocktail-no-results" class="empty-card" style="display: none;">No matches found for that search.</div>
    </div>
  ` : '';

  const renderSpecialCard = (s) => {
    const badgeList = s.badges ? s.badges.split(',').map(b => b.trim()).filter(Boolean) : [];
    const description = sanitizeGuestCopy(s.description || '');
    const detailText = sanitizeGuestCopy(s.detailText || '');
    const timeWindow = sanitizeGuestCopy(s.timeWindow || '');
    const sectionKey = sectionKeyForFilter(s.section || 'uncategorized');
    const searchableText = `${s.name} ${s.description || ''} ${s.detailText || ''} ${s.badges || ''}`.toLowerCase();
    const imageSrc = s.imageUrl && typeof s.imageUrl === 'string' ? s.imageUrl.trim() : '';
    return `
      <div class="deal-card${s.isFeatured ? ' featured' : ''}" data-special-card data-section="${escHTML(sectionKey)}" data-search="${escHTML(searchableText)}">
        ${imageSrc ? `<div class="deal-art"><img src="${escHTML(imageSrc)}" alt="${escHTML(s.name)} cocktail image" loading="lazy" /></div>` : ''}
        <div class="deal-info">
          <div class="deal-name-row">
            <span class="deal-name">${escHTML(s.name)}</span>
            ${badgeList.map(b => `<span class="badge">${escHTML(b)}</span>`).join('')}
          </div>
          ${description ? `<div class="deal-desc">${escHTML(description)}</div>` : ''}
          ${detailText ? `<div class="deal-detail">${escHTML(detailText)}</div>` : ''}
          ${timeWindow ? `<div class="deal-time">${escHTML(timeWindow)}</div>` : ''}
        </div>
        ${s.price ? `<div class="deal-price">${escHTML(s.price)}</div>` : ''}
      </div>
    `;
  };

  let specialsHTML = '';
  if (theme && specialsForDisplay.length > 0) {
    if (hasSections) {
      specialsHTML = sections.map(g => `
        <div class="section" data-special-section="${sectionKeyForFilter(g.section || 'uncategorized')}">
          ${g.section ? `
            <div class="section-header">
              <h2>${escHTML(g.section)}</h2>
            </div>
          ` : `
            <div class="section-header">
              <h2>${isToday ? "Tonight's" : dayLabel + "'s"} Specials</h2>
            </div>
          `}
          ${g.items.map(renderSpecialCard).join('')}
        </div>
      `).join('');
    } else {
    specialsHTML = `
        <div class="section">
          <div class="section-header">
            <h2>${isToday ? "Tonight's" : dayLabel + "'s"} Specials</h2>
          </div>
          ${specialsForDisplay.map(renderSpecialCard).join('')}
        </div>
      `;
    }
  }

  const flightSection = (isFriday && flight) ? `
    <div class="section">
      <div class="section-header">
        <h2>This Month's Flight</h2>
      </div>
      <div class="flight-card">
        <div class="flight-theme">${escHTML(flight.theme)}</div>
        ${flight.description ? `<div class="flight-desc">${escHTML(flight.description)}</div>` : ''}
        ${flight.price ? `<div class="flight-price">${escHTML(flight.price)}</div>` : ''}
        <div class="pours">
          ${(flight.pours || []).sort((a,b) => a.displayOrder - b.displayOrder).map((p, i) => `
            <div class="pour">
              <div class="pour-number">${i + 1}</div>
              <div class="pour-info">
                <div class="pour-name">${escHTML(p.spiritName)}</div>
                ${p.description ? `<div class="pour-origin">${escHTML(p.description)}</div>` : ''}
                ${p.tastingNotes ? `<div class="pour-notes">${escHTML(p.tastingNotes)}</div>` : ''}
                ${p.pourSize ? `<div class="pour-size">${escHTML(p.pourSize)}</div>` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  ` : '';

  const bottlesSection = (isSunday && bottles && bottles.length > 0) ? `
    <div class="section">
      <div class="section-header">
        <h2>This Week's Break Even Bottle${bottles.length > 1 ? 's' : ''}</h2>
      </div>
      ${showGiftToYouSubtitle ? '<p class="section-subtitle">Select bottles sold at cost &mdash; our gift to you</p>' : ''}
      ${bottles.map(b => `
        <div class="bottle-card">
          <div class="bottle-head">
            <div class="bottle-head-copy">
              <div class="deal-name">${escHTML(b.name)}</div>
            </div>
            ${formatGuestCharge(b.costPerOz) ? `<div class="deal-price">Price: ${escHTML(formatGuestCharge(b.costPerOz))}</div>` : ''}
          </div>
          ${renderBottleTastingNotes(b)}
        </div>
      `).join('')}
    </div>
  ` : '';

  // Tomorrow preview teaser
  const tomorrowIdx = (DAYS_ORDER.indexOf(activeDay) + 1) % 7;
  const tomorrowDay = DAYS_ORDER[tomorrowIdx];
  const tomorrowTeaser = tomorrowTheme ? `
    <div class="teaser-card">
      <div class="teaser-label">Tomorrow</div>
      <div class="teaser-title">${escHTML(tomorrowTheme.name)}</div>
      ${tomorrowTheme.tagline ? `<div class="teaser-tagline">${escHTML(sanitizeGuestCopy(tomorrowTheme.tagline))}</div>` : ''}
      <a href="/${location.slug}/specials?day=${tomorrowDay}" class="teaser-link">See ${DAY_LABELS[tomorrowDay]}'s specials →</a>
    </div>
  ` : '';

  // Friday flight teaser (non-Friday days only)
  const flightTeaser = (!isFriday && fridayFlight) ? `
    <div class="teaser-card">
      <div class="teaser-label">This Friday</div>
      <div class="teaser-title">Flight Night</div>
      <div class="teaser-tagline">${escHTML(fridayFlight.theme)}</div>
      <a href="/${location.slug}/specials?day=FRIDAY" class="teaser-link">See Friday's lineup →</a>
    </div>
  ` : '';

  const noSpecialsMessage = !theme ? `
    <div class="section">
      <div class="empty-card">
        ${nextAvailable ? `<p>${nextAvailable.title} is coming ${nextAvailable.dayLabel}.</p>` : `<p>No specials posted for ${dayLabel} yet. Check back soon!</p>`}
        ${nextAvailable ? `<p><a href="/${location.slug}/specials?day=${nextAvailable.dayOfWeek}" class="spirit-link">See ${nextAvailable.dayLabel}'s specials →</a></p>` : ''}
      </div>
    </div>
  ` : '';

  const warningLabels = [
    warnings.specials ? 'specials schedule' : null,
    warnings.flight ? 'Friday flight' : null,
    warnings.bottles ? 'Sunday bottle deals' : null,
  ].filter(Boolean);

  const dataWarningMessage = warningLabels.length ? `
    <div class="section">
      <div class="warning-card">
        <p>Some sections are temporarily unavailable (${warningLabels.join(', ')}).</p>
        <a href="${spiritListUrl}" class="spirit-link" target="_blank">Browse Our Spirit List →</a>
      </div>
    </div>
  ` : '';

  const emptyThemeMessage = (theme && specialsForDisplay.length === 0 && !isSundayBottlesDay) ? `
    <div class="section">
      <div class="empty-card">
        <p>${escHTML(themeDescription || `No individual specials for ${dayLabel}.`)}</p>
        <a href="${spiritListUrl}" class="spirit-link" target="_blank">Browse Our Spirit List →</a>
      </div>
    </div>
  ` : '';

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${theme ? escHTML(theme.name) : dayLabel + ' Specials'} - Dram & Draught ${escHTML(location.name)}</title>
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
          --bg-a: #09090c;
          --bg-b: #19151d;
          --panel: #16131a;
          --line: rgba(216, 174, 73, 0.25);
          --text: #efe7d4;
          --muted: #b0a99c;
          --gold: #d9b25f;
          --amber: #b97c3d;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        body {
          font-family: "Palatino Linotype", "Bodoni MT", "Trebuchet MS", Georgia, serif;
          color: var(--text);
          background:
            radial-gradient(1200px 620px at 15% -8%, rgba(216, 174, 73, 0.2), transparent 60%),
            radial-gradient(1000px 520px at 100% 0%, rgba(185, 124, 61, 0.24), transparent 55%),
            linear-gradient(180deg, var(--bg-a), #0a0a0b 44%, #080809 100%);
          min-height: 100vh;
          animation: fadeIn .45s ease-out;
        }
        .header {
          background:
            linear-gradient(180deg, rgba(31,27,35,0.95), rgba(11,10,12,0.96)),
            radial-gradient(circle at 30% 0%, rgba(216,174,73,0.16), transparent 40%);
          text-align: center;
          padding: 28px 20px 10px;
          border-bottom: 1px solid var(--line);
        }
        .brand {
          font-size: clamp(1.8rem, 7vw, 2.3rem);
          font-weight: 800;
          line-height: 1;
          background: linear-gradient(135deg, #f3d7a5, var(--gold), var(--amber));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }
        .location-name {
          color: var(--muted);
          font-size: 0.9rem;
          text-transform: uppercase;
          letter-spacing: 0.1em;
          margin-top: 7px;
        }
        .day-nav {
          position: sticky;
          top: 0;
          z-index: 2;
          display: flex;
          gap: 6px;
          padding: 12px 16px;
          overflow-x: auto;
          -webkit-overflow-scrolling: touch;
          scrollbar-width: none;
          justify-content: center;
          background: rgba(9, 9, 12, 0.8);
          backdrop-filter: blur(6px);
          border-bottom: 1px solid var(--line);
        }
        .day-nav::-webkit-scrollbar { display: none; }
        .day-tab {
          padding: 8px 12px;
          border-radius: 999px;
          font-size: 0.81rem;
          font-weight: 700;
          color: #91897d;
          text-decoration: none;
          white-space: nowrap;
          transition: all 0.18s;
          border: 1px solid transparent;
          background: rgba(255,255,255,0.02);
        }
        .day-tab:hover { color: #ddd5c7; background: rgba(255,255,255,0.04); }
        .day-tab.active {
          color: #14110d;
          background: linear-gradient(135deg, var(--gold), var(--amber));
          border-color: transparent;
          font-weight: 800;
          box-shadow: 0 8px 16px rgba(0,0,0,0.35);
        }
        .day-tab.today:not(.active) {
          border-color: rgba(216,174,73,0.35);
          color: #d8c190;
        }
        .hours-line {
          text-align: center;
          padding: 9px 16px;
          color: #9d9485;
          font-size: 0.82rem;
          background: rgba(0,0,0,0.28);
          border-bottom: 1px solid rgba(216,174,73,0.12);
        }
        .hours-line span { color: var(--gold); font-weight: 600; }
        .theme-banner {
          margin: 14px auto 4px;
          max-width: 620px;
          background: linear-gradient(135deg, rgba(216,174,73,0.18), rgba(185,124,61,0.12));
          border: 1px solid rgba(216,174,73,0.22);
          border-radius: 16px;
          padding: 22px 20px 20px;
          text-align: center;
          box-shadow: 0 12px 30px rgba(0,0,0,0.35);
        }
        .theme-day {
          color: var(--gold);
          font-size: 0.78rem;
          text-transform: uppercase;
          letter-spacing: 0.16em;
          font-weight: 700;
        }
        .today-badge {
          display: inline-block;
          background: rgba(216,174,73,0.2);
          color: #14100b;
          font-size: 0.65rem;
          padding: 2px 8px;
          border-radius: 999px;
          margin-left: 8px;
          font-weight: 800;
          letter-spacing: 0.06em;
          vertical-align: middle;
          text-transform: uppercase;
        }
        .theme-name {
          font-size: clamp(1.6rem, 7vw, 2rem);
          font-weight: 800;
          color: #fff;
          margin: 8px 0 4px;
        }
        .theme-tagline {
          color: var(--gold);
          font-style: italic;
          font-size: 0.98rem;
        }
        .theme-desc {
          color: #9d9485;
          font-size: 0.92rem;
          margin-top: 8px;
          max-width: 500px;
          margin-left: auto;
          margin-right: auto;
          line-height: 1.55;
        }
        .container { max-width: 650px; margin: 0 auto; padding: 0 16px 14px; }
        .section { margin: 24px 0; animation: fadeIn .35s ease both; }
        .cocktail-search {
          display: flex;
          gap: 8px;
          align-items: center;
          margin: 2px 0 10px;
        }
        .cocktail-search input {
          flex: 1;
          min-width: 0;
          border: 1px solid #2a262d;
          border-radius: 12px;
          background: rgba(0, 0, 0, 0.35);
          color: var(--text);
          padding: 11px 12px;
          font-size: 0.9rem;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
        }
        .cocktail-search input:focus {
          border-color: rgba(216,174,73,0.5);
          box-shadow: 0 0 0 3px rgba(216,174,73,0.18);
        }
        .filter-chips {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin-top: 12px;
        }
        .filter-chip {
          border: 1px solid #2a262d;
          border-radius: 999px;
          background: rgba(255,255,255,0.02);
          color: #c2b7a9;
          padding: 6px 12px;
          font-size: 0.76rem;
          font-weight: 700;
          letter-spacing: 0.02em;
          cursor: pointer;
        }
        .filter-chip:hover {
          border-color: rgba(216,174,73,0.45);
          color: #fff;
        }
        .filter-chip.is-active {
          border-color: transparent;
          background: linear-gradient(135deg, var(--gold), var(--amber));
          color: #14110d;
        }
        .filter-reset {
          white-space: nowrap;
          border: 1px solid rgba(216,174,73,0.35);
          border-radius: 12px;
          background: rgba(216,174,73,0.11);
          color: #f8ecd2;
          padding: 8px 10px;
          font-size: 0.76rem;
          cursor: pointer;
          font-weight: 700;
        }
        .filter-reset:hover {
          background: rgba(216,174,73,0.18);
        }
        .filter-reset:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }
        .deal-card.is-hidden {
          display: none !important;
        }
        .section-header {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 12px;
          padding: 0 2px;
        }
        .section-header h2 {
          font-size: 1.02rem;
          color: var(--gold);
          font-weight: 800;
          letter-spacing: 0.02em;
          text-transform: uppercase;
        }
        .section-subtitle { color: #9c9486; font-size: 0.84rem; margin: -6px 0 14px 4px; }
        .bottle-card {
          background: var(--panel);
          border: 1px solid #2a262d;
          border-radius: 14px;
          padding: 14px;
          margin-bottom: 10px;
          box-shadow: 0 10px 22px rgba(0,0,0,0.25);
          display: flex;
          flex-direction: column;
          gap: 10px;
          transition: border-color 0.2s, transform 0.2s;
        }
        .bottle-card:hover { border-color: rgba(216,174,73,0.36); transform: translateY(-1px); }
        .bottle-head {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .bottle-head-copy { min-width: 0; flex: 1; }
        .bottle-note-block {
          border-top: 1px solid #2a262d;
          padding-top: 10px;
        }
        .bottle-note-summary {
          color: #f8efd6;
          font-size: 0.82rem;
          font-weight: 700;
          margin-bottom: 6px;
        }
        .bottle-note-list {
          list-style: none;
          padding: 0;
          margin: 0;
          display: grid;
          gap: 7px;
        }
        .bottle-note-item {
          color: #9f9688;
          font-size: 0.82rem;
          line-height: 1.45;
          display: grid;
          grid-template-columns: auto 1fr;
          gap: 9px;
        }
        .bottle-note-label {
          color: #ceb06e;
          white-space: nowrap;
          text-transform: uppercase;
          font-size: 0.62rem;
          letter-spacing: 0.03em;
          font-weight: 700;
          min-width: 64px;
        }
        .deal-card {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          background: var(--panel);
          border: 1px solid #2a262d;
          border-radius: 12px;
          padding: 14px 14px;
          margin-bottom: 10px;
          box-shadow: 0 10px 20px rgba(0,0,0,0.25);
          transition: border-color 0.2s, transform 0.2s;
        }
        .deal-card:hover { border-color: rgba(216,174,73,0.36); transform: translateY(-1px); }
        .deal-card.featured {
          border-color: rgba(216,174,73,0.45);
          box-shadow: 0 0 18px rgba(216,174,73,0.12);
        }
        .deal-art {
          width: 84px;
          height: 84px;
          border-radius: 10px;
          border: 1px solid #2a262d;
          overflow: hidden;
          flex-shrink: 0;
          background: rgba(0,0,0,0.28);
        }
        .deal-art img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }
        .deal-info { min-width: 0; flex: 1; }
        .deal-name-row {
          display: flex;
          align-items: center;
          gap: 7px;
          flex-wrap: wrap;
        }
        .deal-name { font-weight: 700; color: #fff; font-size: 1rem; }
        .deal-desc { color: #a7a095; font-size: 0.85rem; margin-top: 2px; }
        .deal-detail {
          color: #9f9688;
          font-size: 0.82rem;
          margin-top: 6px;
          font-style: italic;
          line-height: 1.5;
        }
        .deal-time {
          color: #be7f42;
          font-size: 0.82rem;
          margin-top: 4px;
        }
        .deal-price {
          margin-left: auto;
          align-self: flex-start;
          color: var(--gold);
          font-weight: 800;
          font-size: 1.05rem;
          white-space: nowrap;
        }
        .badge {
          display: inline-block;
          background: linear-gradient(135deg, rgba(216,174,73,0.18), rgba(185,124,61,0.16));
          color: var(--gold);
          font-size: 0.62rem;
          font-weight: 700;
          padding: 2px 8px;
          border-radius: 999px;
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .flight-card {
          background: linear-gradient(135deg, rgba(216,174,73,0.12), rgba(185,124,61,0.07));
          border: 1px solid rgba(216,174,73,0.22);
          border-radius: 14px;
          padding: 18px 18px 16px;
          box-shadow: 0 10px 24px rgba(0,0,0,0.26);
        }
        .flight-theme { font-size: 1.17rem; font-weight: 800; color: #fff; margin-bottom: 4px; }
        .flight-desc { color: #9d9485; font-size: 0.88rem; margin-bottom: 8px; }
        .flight-price {
          display: inline-block;
          background: linear-gradient(135deg, var(--gold), var(--amber));
          color: #14110d;
          font-weight: 800;
          padding: 4px 14px;
          border-radius: 20px;
          font-size: 0.95rem;
          margin-bottom: 16px;
        }
        .pours { display: flex; flex-direction: column; gap: 10px; }
        .pour {
          display: flex;
          gap: 12px;
          align-items: flex-start;
          background: rgba(0,0,0,0.25);
          border-radius: 10px;
          padding: 12px 12px 12px 14px;
          border: 1px solid rgba(255,255,255,0.05);
        }
        .pour-number {
          width: 26px;
          height: 26px;
          background: linear-gradient(135deg, var(--gold), var(--amber));
          color: #14110d;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          font-size: 0.81rem;
          flex-shrink: 0;
        }
        .pour-info { flex: 1; min-width: 0; }
        .pour-name { font-weight: 700; color: #fff; }
        .pour-origin { color: var(--gold); font-size: 0.82rem; }
        .pour-notes { color: #9d9485; font-size: 0.82rem; margin-top: 3px; font-style: italic; }
        .pour-size { color: #82796c; font-size: 0.75rem; margin-top: 2px; }
        .teaser-card {
          background: linear-gradient(135deg, rgba(216,174,73,0.06), rgba(185,124,61,0.04));
          border: 1px solid rgba(216,174,73,0.15);
          border-radius: 12px;
          padding: 14px 16px;
          margin-bottom: 10px;
          text-align: center;
          box-shadow: inset 0 0 16px rgba(0,0,0,0.18);
        }
        .teaser-label {
          font-size: 0.72rem;
          text-transform: uppercase;
          letter-spacing: 0.12em;
          color: #8f877a;
          font-weight: 700;
          margin-bottom: 4px;
        }
        .teaser-title {
          font-size: 1.03rem;
          font-weight: 800;
          color: #fff;
        }
        .teaser-tagline {
          color: var(--gold);
          font-size: 0.88rem;
          font-style: italic;
          margin-top: 2px;
        }
        .teaser-link {
          display: inline-block;
          margin-top: 8px;
          color: #eadbb4;
          font-size: 0.82rem;
          font-weight: 600;
          text-decoration: none;
        }
        .teaser-link:hover { text-decoration: underline; }
        .warning-card {
          text-align: center;
          background: rgba(234, 179, 8, 0.09);
          border: 1px solid rgba(234,179,8,0.25);
          border-radius: 14px;
          padding: 16px;
          color: #f2d06b;
          box-shadow: 0 8px 24px rgba(0,0,0,0.2);
        }
        .warning-card p { margin-bottom: 10px; line-height: 1.5; }
        .empty-card {
          text-align: center;
          background: var(--panel);
          border: 1px solid #2a262d;
          border-radius: 14px;
          padding: 32px 20px;
          box-shadow: 0 10px 24px rgba(0,0,0,0.2);
        }
        .empty-card p { color: #a39887; line-height: 1.5; }
        .spirit-link {
          display: inline-block;
          margin-top: 16px;
          color: #14110d;
          background: linear-gradient(135deg, var(--gold), var(--amber));
          padding: 10px 22px;
          border-radius: 10px;
          text-decoration: none;
          font-weight: 700;
          font-size: 0.9rem;
          box-shadow: 0 8px 18px rgba(0,0,0,0.28);
        }
        .spirit-link:hover { filter: brightness(1.05); }
        .spirit-cta {
          display: block;
          text-align: center;
          margin: 24px 0 8px;
          padding: 14px 20px;
          background: linear-gradient(135deg, var(--gold), var(--amber));
          color: #14110d;
          font-weight: 800;
          font-size: 0.95rem;
          border-radius: 12px;
          text-decoration: none;
          letter-spacing: 0.02em;
          box-shadow: 0 10px 24px rgba(0,0,0,0.3);
        }
        .spirit-cta:hover { filter: brightness(1.03); }
        .footer {
          text-align: center;
          padding: 24px 20px 32px;
        }
        .back-link {
          display: inline-block;
          color: #938a7b;
          text-decoration: none;
          font-size: 0.9rem;
          font-weight: 600;
        }
        .back-link:hover { color: var(--gold); }
      </style>
    </head>
    <body>
        <div class="header">
        <div class="brand">Dram & Draught</div>
        <div class="location-name">${escHTML(location.name)}</div>
      </div>

      <div class="day-nav">${dayNav}</div>
      ${todayHours ? `<div class="hours-line">Open ${isToday ? 'today' : dayLabel} <span>${escHTML(todayHours)}</span></div>` : ''}
      ${dataWarningMessage}

      ${theme ? `
        <div class="theme-banner">
          <div class="theme-day">${dayLabel}${isToday ? '<span class="today-badge">TODAY</span>' : ''}</div>
          <div class="theme-name">${escHTML(theme.name)}</div>
          ${displayTagline ? `<div class="theme-tagline">${escHTML(displayTagline)}</div>` : ''}
          ${showThemeDescInBanner ? `<div class="theme-desc">${escHTML(themeDescription)}</div>` : ''}
        </div>
      ` : ''}

      <div class="container">
        ${searchSectionUI}
        ${specialsHTML}
        ${emptyThemeMessage}
        ${noSpecialsMessage}
        ${flightSection}
        ${bottlesSection}

        ${tomorrowTeaser || flightTeaser ? `
        <div class="section">
          <div class="section-header">
            <h2>Coming Up</h2>
          </div>
          ${tomorrowTeaser}
          ${flightTeaser}
        </div>
        ` : ''}

        <a href="${spiritListUrl}" class="spirit-cta" target="_blank">Browse Our Full Spirit List →</a>

        <div class="footer">
          <a href="/${location.slug}" class="back-link">← Back to ${escHTML(location.name)}</a>
        </div>
      </div>
      <script>
        (function() {
          const searchInput = document.getElementById('cocktail-search-input');
          const clearFiltersBtn = document.getElementById('cocktail-clear-filters');
          const cards = Array.from(document.querySelectorAll('[data-special-card]'));
          const sections = Array.from(document.querySelectorAll('[data-special-section]'));
          const filters = Array.from(document.querySelectorAll('[data-section-filter]'));
          const noResults = document.getElementById('cocktail-no-results');
          let activeSection = 'all';

          function applyFilters() {
            const query = searchInput ? (searchInput.value || '').trim().toLowerCase() : '';
            let visibleCards = 0;

            cards.forEach((card) => {
              const matchesSection = activeSection === 'all' || card.dataset.section === activeSection;
              const matchesSearch = !query || (card.dataset.search || '').indexOf(query) !== -1;
              const visible = matchesSection && matchesSearch;
              card.classList.toggle('is-hidden', !visible);
              if (visible) visibleCards += 1;
            });

            sections.forEach((section) => {
              const sectionCards = section.querySelectorAll('[data-special-card]');
              const visibleInSection = Array.from(sectionCards).some((card) => !card.classList.contains('is-hidden'));
              section.style.display = visibleInSection ? '' : 'none';
            });

            if (noResults) {
              noResults.style.display = visibleCards > 0 ? 'none' : 'block';
            }

            if (clearFiltersBtn) {
              clearFiltersBtn.disabled = !query;
            }
          }

          function setSectionFilter(filterKey) {
            activeSection = filterKey || 'all';
            filters.forEach((filterBtn) => {
              if ((filterBtn.getAttribute('data-section-filter') || 'all') === activeSection) {
                filterBtn.classList.add('is-active');
                filterBtn.setAttribute('aria-pressed', 'true');
              } else {
                filterBtn.classList.remove('is-active');
                filterBtn.setAttribute('aria-pressed', 'false');
              }
            });
            applyFilters();
          }

          filters.forEach((btn) => {
            btn.addEventListener('click', () => {
              setSectionFilter(btn.getAttribute('data-section-filter'));
            });
          });

          if (searchInput) {
            searchInput.addEventListener('input', applyFilters);
            searchInput.addEventListener('change', applyFilters);
          }

          if (clearFiltersBtn) {
            clearFiltersBtn.addEventListener('click', () => {
              if (searchInput) {
                searchInput.value = '';
              }
              setSectionFilter('all');
            });
          }

          applyFilters();
          setSectionFilter('all');
        })();
      </script>
    </body>
    </html>
  `;
}

module.exports = { generateSpecialsPage, getEasternDay, getEasternMonth, DAYS_ORDER };
